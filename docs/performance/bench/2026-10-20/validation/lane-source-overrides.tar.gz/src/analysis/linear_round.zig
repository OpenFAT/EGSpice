//! Live frequency requests across independent analysis points. A round
//! executes one original solver chunk per point and returns before any
//! analysis resumes, reads its output or changes its matrix/RHS storage.
//! Checkpoints and adaptive decisions remain with each analysis.
const std = @import("std");
const provider = @import("gpu_freq.zig");
const gpu = @import("gpu.zig");
const FS = @import("solver").freq_solve.FreqSolver;

pub const Request = provider.RoundPoint;
pub const SolveError = provider.SolveError;
pub const Stats = provider.Stats;

/// Owns the optional device provider for all rounds of a batch. The
/// analysis retains its point states; this owns only reusable device work.
pub const Driver = struct {
    provider: provider.RoundDriver,

    pub fn init(allocator: std.mem.Allocator, backend: gpu.Request) Driver {
        return .{ .provider = provider.RoundDriver.init(allocator, backend) };
    }

    pub fn deinit(self: *Driver) void {
        self.provider.deinit();
        self.* = undefined;
    }

    pub fn solve(self: *Driver, requests: []const Request, failures: []?SolveError) std.mem.Allocator.Error!Stats {
        validate(requests, failures);
        return self.provider.solve(requests, failures);
    }
};

/// Request buffers and solvers are borrowed only for this call. Every
/// request must belong to a distinct point/solver; errors are point-local.
/// CPU execution uses the same live FreqSolver as the device provider.
pub fn solve(allocator: std.mem.Allocator, backend: gpu.Request, requests: []const Request, failures: []?SolveError) std.mem.Allocator.Error!Stats {
    validate(requests, failures);
    return provider.solveRound(allocator, backend, requests, failures);
}

fn validate(requests: []const Request, failures: []?SolveError) void {
    std.debug.assert(requests.len == failures.len);
    for (requests, 0..) |request, i| {
        std.debug.assert(request.omegas.len > 0 and request.omegas.len <= FS.W);
        for (requests[0..i]) |previous| std.debug.assert(previous.fs != request.fs);
    }
}
