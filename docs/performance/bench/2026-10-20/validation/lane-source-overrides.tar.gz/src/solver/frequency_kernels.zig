//! Frequency lane bodies shared by the device exports and host oracle.
//! A lane is (point, frequency). Matrices use stacked-real [G -ωC; ωC G];
//! each point has its own G/C, RHS and pivot history. No reduction mixes
//! lanes. The positive and transpose solves follow LaneLu's operation order.
const std = @import("std");
const lk = @import("lane_kernels.zig");

pub fn Bodies(comptime P: fn (type) type) type {
    return struct {
        /// One source CSC slot of one lane. `positions[4*slot..][0..4]`
        /// are its G, +ωC, -ωC, G stacked positions. G/C are slot-major
        /// across points, and `point[l]` chooses this frequency's point.
        pub fn fill(slot: usize, l: usize, n_lanes: usize, n_points: usize, offsets: P(u32), g: P(f64), c: P(f64), point: P(u32), omega: P(f64), a: P(f64)) void {
            const p = point[l];
            const gv = g[slot * n_points + p];
            const cv = c[slot * n_points + p];
            a[@as(usize, offsets[4 * slot]) * n_lanes + l] = gv;
            a[@as(usize, offsets[4 * slot + 1]) * n_lanes + l] = omega[l] * cv;
            a[@as(usize, offsets[4 * slot + 2]) * n_lanes + l] = -omega[l] * cv;
            a[@as(usize, offsets[4 * slot + 3]) * n_lanes + l] = gv;
        }

        /// Positive or transpose solve, with one RHS per lane. The
        /// transpose of the stacked-real matrix is the complex adjoint;
        /// the analysis readout applies its existing conjugation.
        pub fn solve(t: lk.LaneTab, indices: P(u32), lx: P(f64), ux: P(f64), diag: P(f64), rhs: P(f64), y: P(f64), out: P(f64), n_lanes: usize, l: usize, adjoint: bool) void {
            const N = n_lanes;
            if (adjoint) {
                for (0..t.n) |k| y[k * N + l] = rhs[@as(usize, indices[t.q + k]) * N + l];
                for (0..t.n) |k| {
                    var v = y[k * N + l];
                    for (indices[t.up + k]..indices[t.up + k + 1]) |p|
                        v -= ux[p * N + l] * y[@as(usize, indices[t.ui + p]) * N + l];
                    y[k * N + l] = v / diag[k * N + l];
                }
                var k: usize = t.n;
                while (k > 0) {
                    k -= 1;
                    var v = y[k * N + l];
                    for (indices[t.lp + k]..indices[t.lp + k + 1]) |p|
                        v -= lx[p * N + l] * y[@as(usize, indices[t.li + p]) * N + l];
                    y[k * N + l] = v;
                }
                for (0..t.n) |r| out[r * N + l] = y[@as(usize, indices[t.pinv + r]) * N + l];
                return;
            }
            for (0..t.n) |r| y[@as(usize, indices[t.pinv + r]) * N + l] = rhs[r * N + l];
            for (0..t.n) |k| {
                const v = y[k * N + l];
                if (v != 0) for (indices[t.lp + k]..indices[t.lp + k + 1]) |p| {
                    y[@as(usize, indices[t.li + p]) * N + l] -= lx[p * N + l] * v;
                };
            }
            var k: usize = t.n;
            while (k > 0) {
                k -= 1;
                const v = y[k * N + l] / diag[k * N + l];
                y[k * N + l] = v;
                if (v != 0) for (indices[t.up + k]..indices[t.up + k + 1]) |p| {
                    y[@as(usize, indices[t.ui + p]) * N + l] -= ux[p * N + l] * v;
                };
            }
            for (0..t.n) |j| out[@as(usize, indices[t.q + j]) * N + l] = y[j * N + l];
        }
    };
}

/// Maps each source slot to its four positions in the stacked CSC.
/// Caller supplies 4*nnz indices. Mirrors freq_solve.StackedPoints.
pub fn positions(src_col_ptr: []const u32, out: []u32) void {
    const n = src_col_ptr.len - 1;
    const nnz = src_col_ptr[n];
    std.debug.assert(out.len == 4 * nnz);
    for (0..n) |j| {
        const start = src_col_ptr[j];
        const len = src_col_ptr[j + 1] - start;
        for (start..src_col_ptr[j + 1]) |p| {
            const top: u32 = @intCast(2 * start + p - start);
            const right = 2 * nnz + top;
            out[4 * p ..][0..4].* = .{ top, top + len, right, right + len };
        }
    }
}

test "frequency fill keeps each point's planes and ragged frequency lanes independent" {
    const t = std.testing;
    const B = Bodies(lk.HostP);
    const N = 5; // deliberately not a SIMD or warp multiple
    const np = 2;
    const nnz = 4;
    var pos: [4 * nnz]u32 = undefined;
    positions(&.{ 0, 2, 4 }, &pos);
    var g = [_]f64{ 4, 9, -1, -2, -3, -4, 5, 7 };
    var c = [_]f64{ 0.01, 0.02, 0, 0.03, 0.04, 0, 0.05, 0.06 };
    var point = [_]u32{ 0, 1, 0, 1, 1 };
    var omega = [_]f64{ 0, 2, 100, -7, 1e6 };
    var a: [4 * nnz * N]f64 = @splat(std.math.nan(f64));
    for (0..nnz) |s| for (0..N) |l| B.fill(s, l, N, np, &pos, &g, &c, &point, &omega, &a);
    for (0..nnz) |s| for (0..N) |l| {
        const gv = g[s * np + point[l]];
        const cv = c[s * np + point[l]];
        const want = [_]f64{ gv, omega[l] * cv, -omega[l] * cv, gv };
        for (0..4) |q| try t.expectEqual(@as(u64, @bitCast(want[q])), @as(u64, @bitCast(a[pos[4 * s + q] * N + l])));
    };
}

test "frequency forward and adjoint lane bodies match LaneLu with mixed and zero right-hand sides" {
    const gpa = std.testing.allocator;
    const SparseLu = @import("sparse_lu.zig").SparseLu;
    const LL = @import("lane_lu.zig").LaneLu(4);
    const B = Bodies(lk.HostP);
    var prng = std.Random.DefaultPrng.init(0xf2e9a);
    const random = prng.random();
    var compared: usize = 0;
    for (0..24) |trial| {
        const n: u32 = @intCast(4 + trial);
        const sys = try SparseLu.test_access.TestSystem.init(gpa, random, n, 0.3);
        defer sys.deinit(gpa);
        const q = try gpa.alloc(u32, n);
        defer gpa.free(q);
        for (q, 0..) |*v, i| v.* = @intCast(i);
        random.shuffle(u32, q);
        var base = try SparseLu.init(gpa, n, sys.col_ptr, q);
        defer base.deinit(gpa);
        base.factor(gpa, sys.col_ptr, sys.row_idx, sys.vals, 1e-3) catch continue;
        if (std.mem.indexOfScalar(bool, base.void_col, true) != null) continue;
        var ll = try LL.init(gpa, &base);
        defer ll.deinit(gpa);
        const built = try lk.buildTab(gpa, &base, sys.col_ptr, 1e-12, 1e-3);
        defer gpa.free(built.idx);
        const vals = try gpa.alloc(LL.V, sys.vals.len);
        defer gpa.free(vals);
        for (vals, sys.vals) |*v, x| v.* = .{ x, x * 1.1, x * 0.9, x };
        const bad = ll.refactor(LL.Plane{ .col_ptr = sys.col_ptr, .vals = vals }, 1e-12);
        const work = try gpa.alloc(LL.V, 4 * n);
        defer gpa.free(work);
        const rhs = work[0..n];
        const want = work[n..][0..n];
        const got = work[2 * n ..][0..n];
        const y = work[3 * n ..][0..n];
        for (rhs) |*v| v.* = .{ 0, random.float(f64) - 0.5, random.float(f64), -1 };
        for ([_]bool{ false, true }) |adjoint| {
            if (adjoint) ll.solveT(rhs, want) else ll.solve(rhs, want);
            for (0..4) |l| {
                if (bad & (@as(u64, 1) << @intCast(l)) != 0) continue;
                B.solve(built.tab, built.idx.ptr, @ptrCast(ll.lx.ptr), @ptrCast(ll.ux.ptr), @ptrCast(ll.udiag.ptr), @ptrCast(rhs.ptr), @ptrCast(y.ptr), @ptrCast(got.ptr), 4, l, adjoint);
                for (want, got) |wv, gv| {
                    const wa: [4]f64 = wv;
                    const ga: [4]f64 = gv;
                    try std.testing.expectEqual(@as(u64, @bitCast(wa[l])), @as(u64, @bitCast(ga[l])));
                }
                compared += 1;
            }
        }
    }
    try std.testing.expect(compared > 0);
}
