//! Device evaluation shared by the host, the GPU kernels and runtime-loaded
//! devices: forward-mode AD scalars, the per-type SoA batch behind the
//! `Batch`/`Hooks` ABI, and the one `evalRange` body both backends run.
//! Also the build root of every per-model object, GPU image and HDL `.so`.
//! Cites VerA's device contract (`contract`) and the Verilog-AMS LRM
//! sections named at each use; ngspice's hfetload.c, mesaload.c,
//! hfet2load.c, vsrcacct.c, isrcacct.c, nevalsrc.c and the `*trunc.c` LTE
//! routines where a host rule reproduces them; dev/devices/abi.md and
//! dev/devices/gpu-evaluation.md for the ABI and the GPU path.

const std = @import("std");
const builtin = @import("builtin");

/// No alternate signal stack, in any mode. std reserves it as a 256 KB
/// threadlocal per compilation unit, and every per-model object is its own
/// unit, so Debug's static TLS reached 16.25 MB with 64 models. That exceeds
/// `Io.Threaded`'s 16 MB default thread stack, and glibc's pthread_create
/// returns EINVAL for a stack that cannot hold the TLS (#24). This root
/// spawns no thread, so it never attached the stack; the exe's root keeps
/// Debug's stack-overflow trace for the threads it does spawn.
pub const std_options: std.Options = .{ .signal_stack_size = null };

/// VerA's device/host contract checks (`contract.validating`), on in Debug
/// only: off, a device build spends 0.4-1.8% fewer instructions. Off too in a
/// build with GPU kernels (`models.gpu_kernels`, build.zig): validating adds a
/// Debug-only `su_ok` field to Model, and the kernels compile at .fast without
/// it, so the uploaded rows would read at the wrong stride.
/// Only a host device object (eval.zig as the build root) has the per-model
/// `models` module; a runtime `.hdl` build (VerA's shim re-exports this decl
/// from `dyn`) has neither it nor GPU kernels, so it keeps the Debug checks.
pub const vera_validate_contract = @import("builtin").mode == .debug and
    !(@import("root") == @This() and gpuKernelsBuilt());

fn gpuKernelsBuilt() bool {
    const models = @import("models");
    return @hasDecl(models, "gpu_kernels") and models.gpu_kernels;
}
const contract = @import("contract");
const gompute = @import("gompute");
const ir = @import("device_abi");
// NVPTX/AMDGCN have no libm, so `@exp`/`@log`/`@sin` and std's pow/sinh/cosh
// do not compile there; gompute.math replaces them. exp, exp2, log, log2,
// log10 and pow run one body on host and device (no libm forwarding);
// tanh, sinh, cosh and atan still call std.math on the host. `expm1` comes
// from it too: std's uses `doNotOptimizeAway`, which AMDGCN cannot lower.
const dmath = gompute.math;

/// Whether `@mulAdd` is a native instruction. Without the feature it lowers to
/// a libm `fma()` call per lane, far slower than the two-rounding form.
/// It is `@mulAdd` rather than `@setFloatMode(.optimized)` on purpose: that
/// mode also grants `nnan`/`ninf`, and `Dual.div` must be allowed to divide by
/// zero (Verilog-A permits `V/r` with r = 0) so SparseLu's isFinite check can
/// catch the result.
// ponytail: an arch switch covers every shipped target; add a `-Dfma` option
// only when a target needs to override it.
const fma_ok = switch (builtin.target.cpu.arch) {
    .x86_64 => std.Target.x86.featureSetHas(builtin.target.cpu.features, .fma),
    .aarch64, .aarch64_be => true,
    .nvptx64, .amdgcn => true,
    else => false, // else: no shipped target beyond these has a fused multiply-add guaranteed
};

/// A `Dual` family over lanes `0..n` with unknown u on lane u, every value
/// carrying all n lanes. For tests and one-off evaluations; `evalRange`
/// builds its families from a device's `Basis`.
pub fn Dual(comptime N: usize, comptime F: type) type {
    const lane = comptime blk: {
        var l: [N]u8 = undefined;
        for (&l, 0..) |*e, u| e.* = u;
        break :blk l;
    };
    return DualFor(F, &lane, false, false);
}

/// Number of lanes `lane` maps unknowns onto.
fn laneCount(comptime lane: []const u8) usize {
    var n: usize = 0;
    for (lane) |l| if (l != contract.no_lane) {
        n = @max(n, @as(usize, l) + 1);
    };
    return n;
}

/// Forward-mode AD family: the contract's scalar family `S`
/// (`contract.family_fns`, numerics per `contract.expectFamily`). One eval
/// pass yields the residual and every partial.
///
/// `Of(m)` carries only the lanes of `m`'s unknowns, and a binary operation
/// joins its operands' lanes. `m` is a `contract.MaskOf(lane.len)`.
///
/// `lane[u]` is the derivative lane unknown `u` seeds, or
/// `contract.no_lane`; several unknowns may share one (the narrow basis).
/// `pad` rounds each value's lane count up to a power of two: LLVM splits a
/// 12- or 26-wide vector into shuffles and spills (gummel_poon's eval body
/// doubled). The pad lanes hold zeros (or a NaN from a 0/0) that nothing
/// reads.
/// `F` is the float width of the derivative half only. The value half and
/// every boundary (`con`/`scale`/`addC`/`val`/`ddxAt`) stay f64, so the
/// residual is identical at either width. `F = f32` trades Newton iterations
/// for GPU throughput; see `jacFloat` and `gpuJacFloat` for who takes it.
fn DualFor(comptime F: type, comptime lane: []const u8, comptime pad: bool, comptime collapsed: bool) type {
    const n_lanes = laneCount(lane);
    // A lane set, one bit per lane.
    const L = Mask(n_lanes);
    // A mask over the unknowns.
    const M = Mask(lane.len);
    return struct {
        /// Read by the generated device: the builder already applied
        /// `D.collapse` to the scatter tapes.
        pub const collapse_applied = collapsed;
        pub const V = f64;

        /// The lanes the unknowns in `m` occupy, one bit per lane.
        fn lanesOf(comptime m: M) L {
            @setEvalBranchQuota(10 * lane.len + 1000);
            var s: L = 0;
            for (lane, 0..) |l, u| {
                if (has(m, u) and l != contract.no_lane) s |= @as(L, 1) << l;
            }
            return s;
        }

        fn width(comptime ls: L) usize {
            const n = @popCount(ls);
            return if (pad and n != 0) std.math.ceilPowerOfTwoAssert(usize, n) else n;
        }

        fn unknownBit(comptime u: usize) M {
            return @as(M, 1) << u;
        }

        /// The type of a value that depends on the unknowns in `m`.
        pub fn Of(comptime m: M) type {
            return Val(lanesOf(m));
        }
        /// A constant: every lane +0.
        pub fn con(c: f64) Of(0) {
            return .{ .v = c, .d = @splat(0) };
        }
        /// Unknown `u` at `v`, its lane seeded with 1. An unknown without a
        /// lane (`contract.no_lane`) comes back as a constant.
        pub fn probe(comptime u: usize, v: f64) Of(unknownBit(u)) {
            const T = Of(unknownBit(u));
            var d: T.Lanes = @splat(0);
            if (comptime lane[u] != contract.no_lane) d[comptime T.pos(lane[u])] = 1;
            return .{ .v = v, .d = d };
        }
        /// `a` where the indicator `c` is nonzero (NaN included), else `b`,
        /// lanes included.
        pub fn sel(c: anytype, a: anytype, b: anytype) Val(@TypeOf(a).lanes | @TypeOf(b).lanes) {
            const r = @TypeOf(a).lanes | @TypeOf(b).lanes;
            // `c.v != 0.0` from the bits: Zig 0.17's self-hosted x86_64
            // backend reads `!=`'s parity-or-nonzero flags a second time
            // after clobbering them, so `pick` was true at c == 0 (#25,
            // dev/zig-backend.md). Same answer for every c, NaN included.
            const pick = @as(u64, @bitCast(c.v)) << 1 != 0;
            // A lane select, not a branch: on the GPU each thread's indicator
            // differs, and selection is exact, so the bits are the branch's.
            const d = if (comptime width(r) == 0) a.spread(r) else @select(F, @as(@Vector(width(r), bool), @splat(pick)), a.spread(r), b.spread(r));
            return .{ .v = if (pick) a.v else b.v, .d = d };
        }

        /// A value carrying the lanes in `ls`, in ascending lane order.
        fn Val(comptime ls: L) type {
            return struct {
                v: f64,
                /// Aligned to the element, not the vector: natural vector
                /// alignment pads 8 f64 lanes from 72 to 128 bytes, and
                /// nothing reads `d` through a pointer that needs it.
                d: Lanes align(@alignOf(F)),

                /// The lanes this value carries, one bit per lane.
                pub const lanes = ls;
                const Lanes = @Vector(width(ls), F);
                const T = @This();

                comptime {
                    // The value, then the lanes with no gap.
                    std.debug.assert(@sizeOf(T) == std.mem.alignForward(usize, @sizeOf(f64) + @sizeOf(Lanes), @alignOf(f64)));
                }

                /// Where lane `l` sits in `d`.
                fn pos(comptime l: usize) usize {
                    return @popCount(ls & ((@as(L, 1) << l) - 1));
                }
                inline fn k(c: f64) Lanes {
                    return @splat(@floatCast(c));
                }
                inline fn map(a: T, v: f64, c: f64) T {
                    return .{ .v = v, .d = a.d * k(c) };
                }
                /// These lanes laid out as `to_ls`'s. New and pad lanes are +0.
                inline fn spread(a: T, comptime to_ls: L) @Vector(width(to_ls), F) {
                    if (ls & ~to_ls != 0) @compileError("Dual: lanes do not widen");
                    if (ls == to_ls) return a.d;
                    if (ls == 0) return @splat(0);
                    const idx = comptime blk: {
                        var idx: [width(to_ls)]i32 = @splat(-1);
                        var j: usize = 0;
                        for (0..n_lanes) |l| if (has(to_ls, l)) {
                            if (has(ls, l)) idx[j] = pos(l);
                            j += 1;
                        };
                        break :blk idx;
                    };
                    return @shuffle(F, a.d, @as(@Vector(1, F), @splat(0)), idx);
                }
                fn toLanes(a: T, comptime to_ls: L) Val(to_ls) {
                    return .{ .v = a.v, .d = a.spread(to_ls) };
                }

                /// Widens to `Of(m)`, new lanes +0. A compile error when `m`
                /// drops a lane this value carries.
                pub fn to(a: T, comptime m: M) Of(m) {
                    return a.toLanes(Of(m).lanes);
                }
                pub fn val(a: T) f64 {
                    return a.v;
                }
                /// The partial with respect to unknown `u`, widened to f64.
                pub fn ddxAt(a: T, comptime u: usize) f64 {
                    const l = lane[u];
                    if (comptime l == contract.no_lane or !has(ls, l)) return 0.0;
                    return a.d[comptime pos(l)];
                }
                /// Every lane widened to f64, pad lanes included, so `F`
                /// never leaks past the arithmetic.
                pub inline fn grad(a: T) @Vector(width(ls), f64) {
                    return if (F == f64) a.d else @floatCast(a.d);
                }

                pub fn add(a: T, b: anytype) Val(ls | @TypeOf(b).lanes) {
                    const r = ls | @TypeOf(b).lanes;
                    return .{ .v = a.v + b.v, .d = a.spread(r) + b.spread(r) };
                }
                pub fn sub(a: T, b: anytype) Val(ls | @TypeOf(b).lanes) {
                    const r = ls | @TypeOf(b).lanes;
                    return .{ .v = a.v - b.v, .d = a.spread(r) - b.spread(r) };
                }
                pub fn neg(a: T) T {
                    return .{ .v = -a.v, .d = -a.d };
                }
                /// Lanes by the product rule, fused into one rounding where
                /// `fma_ok`, so they differ in the last bit between targets
                /// with and without FMA; the value never does.
                pub fn mul(a: T, b: anytype) Val(ls | @TypeOf(b).lanes) {
                    const B = @TypeOf(b);
                    const J = Val(ls | B.lanes);
                    if (B.lanes == 0) return .{ .v = a.v * b.v, .d = a.spread(J.lanes) * J.k(b.v) };
                    if (ls == 0) return .{ .v = a.v * b.v, .d = b.spread(J.lanes) * J.k(a.v) };
                    return .{ .v = a.v * b.v, .d = mulAddV(J.Lanes, b.spread(J.lanes), J.k(a.v), a.spread(J.lanes) * J.k(b.v)) };
                }
                /// The value is the IEEE quotient (contract §3); the lanes
                /// keep the reciprocal.
                pub fn div(a: T, b: anytype) Val(ls | @TypeOf(b).lanes) {
                    const B = @TypeOf(b);
                    const J = Val(ls | B.lanes);
                    const inv = 1.0 / b.v;
                    const q = a.v / b.v;
                    if (B.lanes == 0) return .{ .v = q, .d = a.spread(J.lanes) * J.k(inv) };
                    return .{ .v = q, .d = mulAddV(J.Lanes, b.spread(J.lanes), J.k(-q), a.spread(J.lanes)) * J.k(inv) };
                }
                pub fn scale(a: T, c: f64) T {
                    return map(a, a.v * c, c);
                }
                pub fn addC(a: T, c: f64) T {
                    return .{ .v = a.v + c, .d = a.d };
                }
                pub fn exp(a: T) T {
                    const e = dmath.exp(a.v);
                    return map(a, e, e);
                }
                pub fn log(a: T) T {
                    return map(a, dmath.log(a.v), 1.0 / a.v);
                }
                /// Same value operation as VerA's precompute scalar, so the
                /// two agree.
                pub fn expm1(a: T) T {
                    return map(a, dmath.expm1(a.v), dmath.exp(a.v));
                }
                /// gompute's port: Zig 0.17's `std.math.log1p` emits an asm
                /// operand AMDGCN cannot select. Bit-identical to std.
                pub fn log1p(a: T) T {
                    return map(a, dmath.log1p(a.v), 1.0 / (1.0 + a.v));
                }
                /// Slope `0.5/sqrt(x)`, and 0 rather than inf or NaN where
                /// `sqrt(x)` is not positive.
                pub fn sqrt(a: T) T {
                    const s = @sqrt(a.v);
                    return map(a, s, if (s > 0.0) 0.5 / s else 0.0);
                }
                pub fn sin(a: T) T {
                    return map(a, dmath.sin(a.v), dmath.cos(a.v));
                }
                pub fn cos(a: T) T {
                    return map(a, dmath.cos(a.v), -dmath.sin(a.v));
                }
                pub fn tanh(a: T) T {
                    const th = dmath.tanh(a.v);
                    return map(a, th, 1.0 - th * th);
                }
                /// `x^c`, slope `c·x^c/x`: one `pow`, exact for x != 0 (LRM
                /// §4.3.1 negative bases included). At x == 0 the slope takes
                /// a second `pow` because `c·p/x` is 0/0 there and c == 1
                /// must still give slope 1. A non-finite slope becomes 0.
                pub fn pow(a: T, c: f64) T {
                    const p = dmath.pow(a.v, c);
                    const slope = if (a.v != 0.0) c * p / a.v else c * dmath.pow(a.v, c - 1.0);
                    return map(a, p, if (std.math.isFinite(slope)) slope else 0.0);
                }
                pub fn atan(a: T) T {
                    return map(a, dmath.atan(a.v), 1.0 / (1.0 + a.v * a.v));
                }
                pub fn sinh(a: T) T {
                    return map(a, dmath.sinh(a.v), dmath.cosh(a.v));
                }
                pub fn cosh(a: T) T {
                    return map(a, dmath.cosh(a.v), dmath.sinh(a.v));
                }
                // Comparisons return a 0/1 indicator without lanes; `sel`
                // carries the lanes of the operand it picks.

                /// 1 when `a < b`, else 0 (NaN on either side gives 0).
                pub fn lt(a: T, b: anytype) Of(0) {
                    return con(@floatFromInt(@intFromBool(a.v < b.v)));
                }
                /// 1 when `a <= b`, else 0 (NaN on either side gives 0).
                pub fn le(a: T, b: anytype) Of(0) {
                    return con(@floatFromInt(@intFromBool(a.v <= b.v)));
                }
                /// 1 when `a == b`, else 0 (NaN on either side gives 0).
                pub fn eq(a: T, b: anytype) Of(0) {
                    return con(@floatFromInt(@intFromBool(a.v == b.v)));
                }
            };
        }
    };
}

inline fn mulAddV(comptime Vec: type, a: Vec, b: Vec, c: Vec) Vec {
    return if (fma_ok) @mulAdd(Vec, a, b, c) else a * b + c;
}

/// Value-only family for the paths that read no partial: `evalQRange`, the
/// charge-tape kernel and every value entry point (`setup`, `limit`,
/// `updateState`, ...). Every method is the `.v` line of the matching
/// `DualFor` method verbatim, so it computes the bits `eval` computes
/// without paying for the gradient.
fn RealFor(comptime collapsed: bool) type {
    return struct {
        v: f64,

        const Self = @This();
        pub const collapse_applied = collapsed;
        pub const V = f64;
        pub const lanes: u64 = 0;

        pub fn Of(comptime _: anytype) type {
            return Self;
        }
        pub fn con(c: f64) Self {
            return .{ .v = c };
        }
        pub fn probe(comptime _: usize, v: f64) Self {
            return .{ .v = v };
        }
        pub fn sel(c: Self, a: Self, b: Self) Self {
            return if (c.v != 0.0) a else b;
        }
        pub fn to(a: Self, comptime _: anytype) Self {
            return a;
        }
        pub fn val(a: Self) f64 {
            return a.v;
        }
        /// Always 0; the contract requires the accessor.
        pub fn ddxAt(_: Self, comptime _: usize) f64 {
            return 0.0;
        }
        pub fn add(a: Self, b: Self) Self {
            return .{ .v = a.v + b.v };
        }
        pub fn sub(a: Self, b: Self) Self {
            return .{ .v = a.v - b.v };
        }
        pub fn neg(a: Self) Self {
            return .{ .v = -a.v };
        }
        pub fn mul(a: Self, b: Self) Self {
            return .{ .v = a.v * b.v };
        }
        pub fn div(a: Self, b: Self) Self {
            return .{ .v = a.v / b.v };
        }
        pub fn scale(a: Self, c: f64) Self {
            return .{ .v = a.v * c };
        }
        pub fn addC(a: Self, c: f64) Self {
            return .{ .v = a.v + c };
        }
        pub fn exp(a: Self) Self {
            return .{ .v = dmath.exp(a.v) };
        }
        pub fn log(a: Self) Self {
            return .{ .v = dmath.log(a.v) };
        }
        pub fn expm1(a: Self) Self {
            return .{ .v = dmath.expm1(a.v) };
        }
        pub fn log1p(a: Self) Self {
            return .{ .v = dmath.log1p(a.v) };
        }
        pub fn sqrt(a: Self) Self {
            return .{ .v = @sqrt(a.v) };
        }
        pub fn sin(a: Self) Self {
            return .{ .v = dmath.sin(a.v) };
        }
        pub fn cos(a: Self) Self {
            return .{ .v = dmath.cos(a.v) };
        }
        pub fn tanh(a: Self) Self {
            return .{ .v = dmath.tanh(a.v) };
        }
        pub fn sinh(a: Self) Self {
            return .{ .v = dmath.sinh(a.v) };
        }
        pub fn cosh(a: Self) Self {
            return .{ .v = dmath.cosh(a.v) };
        }
        pub fn atan(a: Self) Self {
            return .{ .v = dmath.atan(a.v) };
        }
        pub fn pow(a: Self, c: f64) Self {
            return .{ .v = dmath.pow(a.v, c) };
        }
        pub fn lt(a: Self, b: Self) Self {
            return con(@floatFromInt(@intFromBool(a.v < b.v)));
        }
        pub fn le(a: Self, b: Self) Self {
            return con(@floatFromInt(@intFromBool(a.v <= b.v)));
        }
        pub fn eq(a: Self, b: Self) Self {
            return con(@floatFromInt(@intFromBool(a.v == b.v)));
        }
    };
}

/// The value-only family every non-eval entry point runs on.
const Real = RealFor(false);

/// Derivative width of `Dual` for device D on the host. f32 only when the
/// device declares `jac_f32_host`: the f32 Jacobian helps some CPU decks and
/// costs others extra gmin-ladder steps (dev/analysis/refactoring.md, "Retired
/// paths"; the per-deck numbers were not kept).
pub fn jacFloat(comptime D: type) type {
    return if (@hasDecl(D, "jac_f32_host") and D.jac_f32_host) f32 else f64;
}

/// Derivative width of `Dual` for device D in its GPU kernel: f32 whenever the
/// device permits it with `jac_f32`, since GPUs run f32 many times faster.
pub fn gpuJacFloat(comptime D: type) type {
    return if (@hasDecl(D, "jac_f32") and D.jac_f32) f32 else f64;
}

// The ABI types a module importing only this file (the runtime `.so` shim,
// the test suites) needs.

/// `abi.NoiseSource`, one priced generator of `Hooks.collect_noise`.
pub const NoiseSource = ir.NoiseSource;
/// `abi.NoiseGen`, the entries of a device's `noise_gens`.
pub const NoiseGen = ir.NoiseGen;
/// `abi.PsdTerm`, what a device's `noisePsd` returns per generator.
pub const PsdTerm = ir.PsdTerm;
/// `abi.Planes`, the value planes `Batch.eval` stamps into.
pub const Planes = ir.Planes;
/// `abi.Batch`, what `ProtoStore.finalize` returns.
pub const Batch = ir.Batch;
/// `abi.Proto`, the staging handle `deviceVtable(...).proto_create` returns.
pub const Proto = ir.Proto;
const GROUND = ir.GROUND;
const StateCtlOp = ir.StateCtlOp;
const lane_block_size = ir.gpu_lane_block_size;
const SimState = ir.SimState;
const ParamRef = ir.ParamRef;
const Hooks = ir.Hooks;
const PatternView = ir.PatternView;
const PatternBuilder = ir.PatternBuilder;
const GpuPayload = ir.GpuPayload;
const DeviceVtable = ir.DeviceVtable;

/// The host's mask over `n` unknowns or lanes: u64, wider past 64 (#117).
const Mask = contract.MaskOf;

/// A `contract.Mask(D)` mask over `n` unknowns as `Mask(n)`. A device past
/// 64 unknowns without `deriv_reads` keeps u64 masks, all ones meaning every
/// unknown, so the bits u64 cannot hold are set too.
fn widen(comptime n: usize, m: anytype) Mask(n) {
    if (@TypeOf(m) == Mask(n) or n <= 64) return m;
    return if (m == std.math.maxInt(u64)) std.math.maxInt(Mask(n)) else m;
}

/// The low `n` bits of `Mask(n)`.
fn lowBits(comptime n: usize) Mask(n) {
    const M = Mask(n);
    return if (n == @bitSizeOf(M)) std.math.maxInt(M) else (@as(M, 1) << @intCast(n)) - 1;
}

/// Bit `u` of `m`.
inline fn has(m: anytype, u: usize) bool {
    return (m >> @intCast(u)) & 1 != 0;
}

/// Fills the gather, residual-row and Jacobian-slot tapes from the flat node
/// list (`[id * n_u + u]`). Ground rows go to row `pv.n`. The slot tape holds
/// only the entries `pat` sets, row-major, `slots.len / count` per instance
/// (`SlotMap`); a ground one goes to `pv.trash_slot`. Asserts every other
/// (row, col) is in the pattern, that `pat` has `n_u` rows, and that
/// `gath` and `rhs_idx` match `nodes` and `slots` fills exactly.
fn buildTapes(comptime M: type, nodes: []const u32, n_u: usize, pat: []const M, pv: PatternView, gath: []u32, rhs_idx: []u32, slots: []u32) void {
    std.debug.assert(n_u > 0);
    std.debug.assert(pat.len == n_u);
    std.debug.assert(nodes.len % n_u == 0);
    std.debug.assert(gath.len == nodes.len);
    std.debug.assert(rhs_idx.len == nodes.len);
    const count = nodes.len / n_u;
    var k: usize = 0;
    for (0..count) |id| {
        const nd = nodes[id * n_u ..][0..n_u];
        for (nd, 0..) |node, u| {
            gath[id * n_u + u] = node;
            rhs_idx[id * n_u + u] = if (node == GROUND) pv.n else node;
        }
        for (nd, 0..) |r, ru| for (nd, 0..) |c, cu| {
            if (!has(pat[ru], cu)) continue;
            slots[k] = if (r == GROUND or c == GROUND) pv.trash_slot else pv.findSlot(r, c).?;
            k += 1;
        };
    }
    std.debug.assert(k == slots.len);
}

/// D's slot tape layout: `k` entries per instance, one per set bit of
/// `jacPattern(D)` in row-major order, and `at[ru * n_u + cu]` the position of
/// entry (ru, cu) among them. A structural zero has no slot, so no stamp, no
/// tape entry and no GPU staging cell exists for it.
fn SlotMap(comptime D: type) type {
    const n_u = contract.nU(D);
    return struct {
        const pat = jacPattern(D);
        /// Row `ru`'s first position, so `at` is O(1): a dense device past
        /// 64 unknowns calls it n_u^2 times (#117).
        const row_start: [n_u + 1]usize = blk: {
            @setEvalBranchQuota(100_000);
            var s: [n_u + 1]usize = undefined;
            s[0] = 0;
            for (pat, 0..) |row, r| s[r + 1] = s[r] + @popCount(row & lowBits(n_u));
            break :blk s;
        };
        pub const k: usize = row_start[n_u];
        /// Entry (ru, cu)'s position; a compile error for a structural zero.
        pub fn at(comptime ru: usize, comptime cu: usize) usize {
            comptime {
                if (!has(pat[ru], cu)) @compileError(@typeName(D) ++ " stamps an entry outside its jac/q pattern");
                return row_start[ru] + @popCount(pat[ru] & ((@as(Mask(n_u), 1) << @intCast(cu)) - 1));
            }
        }
    };
}

/// D's lim plane layout: `k` values per instance, one per unknown `limit`
/// writes (`contract.limitWrites`), and `at(u)` unknown u's position among
/// them. Nothing reads a lim value `limit` does not write.
fn LimMap(comptime D: type) type {
    const n_u = contract.nU(D);
    const writes = limitWritesOf(D);
    return struct {
        pub const k: usize = @popCount(writes);
        pub fn at(comptime u: usize) usize {
            comptime {
                if (!has(writes, u)) @compileError(@typeName(D) ++ " reads a lim value its `limit` does not write");
                return @popCount(writes & ((@as(Mask(n_u), 1) << @intCast(u)) - 1));
            }
        }
    };
}

/// D's structural Jacobian, resistive and reactive combined: bit `cu` of row
/// `ru` is set when the device can write local entry (ru, cu).
fn jacPattern(comptime D: type) [contract.nU(D)]Mask(contract.nU(D)) {
    var out = rowPattern(D, "jac_pattern");
    // Without `q` there is no reactive half; `rowPattern` would call it dense.
    if (@hasDecl(D, "q")) {
        const q = rowPattern(D, "q_pattern");
        for (&out, q) |*o, qm| o.* |= qm;
    }
    return out;
}

/// The pattern decl `name` (`jac_pattern` or `q_pattern`). VerA omits it
/// past about 2048 unknowns; each row is then the lanes `deriv_reads` gives
/// it plus its `jac_const` columns, all ones (dense) without `deriv_reads`.
fn rowPattern(comptime D: type, comptime name: []const u8) [contract.nU(D)]Mask(contract.nU(D)) {
    const n_u = contract.nU(D);
    var out: [n_u]Mask(n_u) = undefined;
    if (!@hasDecl(D, name)) {
        @setEvalBranchQuota(100 * n_u + 1000);
        out = @splat(widen(n_u, contract.derivReads(D)) & lowBits(n_u));
        for (contract.jacConst(D)) |e| out[@backingInt(e.row)] |= @as(Mask(n_u), 1) << @intCast(@backingInt(e.col));
        return out;
    }
    for (&out, @field(D, name)) |*o, m| o.* = widen(n_u, m) & lowBits(n_u);
    return out;
}

/// The unknowns `limit` writes and reads, as host masks.
fn limitWritesOf(comptime D: type) Mask(contract.nU(D)) {
    return widen(contract.nU(D), contract.limitWrites(D)) & lowBits(contract.nU(D));
}
fn limitReadsOf(comptime D: type) Mask(contract.nU(D)) {
    return widen(contract.nU(D), contract.limitReads(D)) & lowBits(contract.nU(D));
}

/// Which residual rows D's `eval` (`jac_rows`) or `q` (`q_rows`) ever writes;
/// all rows when undeclared. The others are zero at every bias, so their
/// stamps are dropped at comptime.
///
/// Never derive this from `rowPattern(...)[ru] != 0`. A row can be written
/// with a value that depends on no unknown: `isource` has `jac_pattern =
/// {0, 0}` and still stamps its current into both rows.
fn writtenRows(comptime D: type, comptime name: []const u8) [contract.nU(D)]bool {
    if (!@hasDecl(D, name)) return @splat(true);
    const mask = widen(contract.nU(D), @field(D, name));
    var out: [contract.nU(D)]bool = @splat(true);
    for (&out, 0..) |*o, ru| o.* = has(mask, ru);
    return out;
}

/// The charge sites of D that join the transient LTE (`contract.qLte`), in
/// site order. `q_tape` holds one entry per instance and listed site,
/// indexed `id * lteSites(D).len + j`, the way ngspice's `*trunc.c` routines
/// hand CKTterr one charge state each.
fn lteSites(comptime D: type) []const usize {
    comptime {
        const on = contract.qLte(D);
        var out: [on.len]usize = undefined;
        var n: usize = 0;
        for (on, 0..) |o, k| if (o) {
            out[n] = k;
            n += 1;
        };
        const sites = out[0..n].*;
        return &sites;
    }
}

/// The derivative basis `evalRange` seeds: `w` lanes, and the lane each
/// unknown seeds into.
///
/// Only the unknowns in `contract.derivReads` get a lane: the device reads
/// the others as constants and `jac_const` holds their exact partials. Wide:
/// one lane per read unknown. Narrow, for an instance whose collapse is
/// maximal (`collapse_full`): every merged set is one circuit node, its
/// columns share a matrix slot, and one shared lane computes the summed entry
/// the solver sees. mos1 goes from 6 lanes to 4, one ymm instead of two.
const Basis = struct {
    w: usize,
    /// `lane[u]` is the lane unknown `u` seeds, or `contract.no_lane`.
    lane: []const u8,
};

fn basisOf(comptime D: type, comptime narrow: bool) Basis {
    const n_u = contract.nU(D);
    @setEvalBranchQuota(100 * n_u + 1000);
    const reads = widen(n_u, contract.derivReads(D));
    var lane: [n_u]u8 = @splat(contract.no_lane);
    var of_root: [n_u]u8 = @splat(contract.no_lane);
    var w: usize = 0;
    for (0..n_u) |u| {
        if (!has(reads, u)) continue;
        // The contract guarantees `collapse_full` is resolved.
        const root = if (narrow) D.collapse_full[u] orelse u else u;
        if (of_root[root] == contract.no_lane) {
            of_root[root] = @intCast(w);
            w += 1;
        }
        lane[u] = of_root[root];
    }
    const l = lane;
    return .{ .w = w, .lane = &l };
}

/// One pattern half with a single representative column kept per lane, so a
/// shared lane is stamped once; columns without a lane are dropped (their
/// partials come from `jac_const`). Computed per half because `g_vals` and
/// `c_vals` are separate planes.
///
/// The representative is the lowest alias, not the root: that is the column
/// the wide kernel stamps, so a slot shared with an unrelated column (a gate
/// tied to its drain) sums in the same order and the output stays
/// byte-identical. `alias[cu]` is `collapse_full[cu] != null`; all-false makes
/// this the identity on the laned columns.
fn repMask(comptime n_u: usize, comptime lane: [n_u]u8, comptime alias: [n_u]bool, comptime pat: [n_u]Mask(n_u)) [n_u]Mask(n_u) {
    var out: [n_u]Mask(n_u) = @splat(0);
    for (&out, pat) |*m, row| {
        var rep: [n_u]?usize = @splat(null);
        for (0..n_u) |cu| {
            if (!has(row, cu) or lane[cu] == contract.no_lane) continue;
            const cur = rep[lane[cu]];
            // First column of the lane wins, then any alias beats a root.
            if (cur == null or (!alias[cur.?] and alias[cu])) rep[lane[cu]] = cu;
        }
        for (rep) |c| if (c) |cu| {
            m.* |= @as(Mask(n_u), 1) << @intCast(cu);
        };
    }
    return out;
}

/// The `jac_const` entry for local (row `ru`, column `cu`), if any.
fn constEntry(comptime D: type, comptime ru: usize, comptime cu: usize) ?contract.JacConst(D.U) {
    for (contract.jacConst(D)) |e| {
        if (@backingInt(e.row) == ru and @backingInt(e.col) == cu) return e;
    }
    return null;
}

/// Whether D gets a second `evalRange` instantiation on the narrow basis for
/// its fully collapsed instances. It pays only when it saves a register on
/// AVX2 (dev/devices/abi.md, "Derivative lanes"): the wide dual spans two ymm
/// (4 < w <= 8) and the narrow one fits in one (w <= 4). That admits
/// mos1/2/3/6/9, bsim1, bsim3, hfet2, jfet and mes.
///
/// Limiting adds a correctness gate: the correction is stored per lane, so no
/// two unknowns `limit` writes may share one.
// ponytail: n_u <= 8 keeps bsim4 and hisim wide because nothing prices them
// yet; lift the bound when one of them sits on a benchmark deck.
fn canNarrow(comptime D: type) bool {
    if (!@hasDecl(D, "collapse_full")) return false;
    const n_u = contract.nU(D);
    if (n_u > 8 or n_u <= 4) return false;
    const b = comptime basisOf(D, true);
    if (b.w > 4 or b.w >= comptime basisOf(D, false).w) return false;
    if (@hasDecl(D, "limit")) {
        var seen: [n_u]bool = @splat(false);
        const writes = limitWritesOf(D);
        for (0..n_u) |u| if (has(writes, u)) {
            if (seen[b.lane[u]]) return false;
            seen[b.lane[u]] = true;
        };
    }
    return true;
}

/// LRM §6.3.6 `$mfactor` of one instance: every row it stamps (residual,
/// charge, both Jacobians, LTE charges, AC terms, noise PSDs) scales by it,
/// which is exactly `mfactor` parallel copies, since an instance's internal
/// rows are homogeneous in their own unknowns. VerA scales hierarchical
/// children itself and leaves the top-level instance to the host. A model
/// with its own `m` parameter keeps `mfactor` at 1.
pub inline fn mfactorOf(comptime D: type, inst: anytype) f64 {
    return if (comptime @hasField(D.Instance, "mfactor")) inst.mfactor else 1.0;
}

/// `noisePsd`'s family: `eval`'s wide basis in f64, so a `ddx` in
/// a PSD argument (a channel noise's gm) reads its partial. `Real` would read
/// it as 0 (#119).
fn NoiseFamily(comptime D: type) type {
    const lane = comptime basisOf(D, false).lane[0..contract.nU(D)].*;
    return DualFor(f64, &lane, false, @hasDecl(D, "collapse"));
}

/// Evaluates instances `[first, end)` of D and stamps residual, charge and
/// both Jacobians through `sink`. The one physics body: the host sink adds
/// into the planes, the GPU sink writes per-contribution staging cells.
///
/// `narrow` selects the reduced derivative basis (see `Basis`) and is sound
/// only on maximally collapsed instances, which `ProtoStore.finalize` sorts to
/// `[0, narrow_count)`. `F` is the derivative width: `jacFloat(D)` on the
/// host, `gpuJacFloat(D)` in `DeviceKernel`. `pad` is `host_pad` on the host
/// and false in `DeviceKernel`, where pad lanes cost registers.
fn evalRange(comptime D: type, comptime narrow: bool, comptime F: type, comptime pad: bool, sink: anytype, first: u32, end: u32, sim: SimState, limiting: bool) void {
    @setEvalBranchQuota(1_000_000);
    const SinkT = @typeInfo(@TypeOf(sink)).pointer.child;
    // Strict float mode, as everywhere here: `.optimized` grants `nnan`,
    // which would make the `* mf` of a NaN residual poison before
    // SparseLu's isFinite check sees it (see `fma_ok`).
    const n_u = comptime contract.nU(D);
    const has_limit = comptime @hasDecl(D, "limit");
    const reads = comptime widen(n_u, contract.derivReads(D));
    const jac_pat = comptime rowPattern(D, "jac_pattern");
    const q_pat = comptime rowPattern(D, "q_pattern");
    const jac_row = comptime writtenRows(D, "jac_rows");
    const q_row = comptime writtenRows(D, "q_rows");

    const B = comptime basisOf(D, narrow);
    const W = B.w;
    const lane = comptime B.lane[0..n_u].*;
    const alias = comptime blk: {
        var a: [n_u]bool = @splat(false);
        if (narrow) for (&a, D.collapse_full) |*o, c| {
            o.* = c != null;
        };
        break :blk a;
    };
    const jac_rep = comptime repMask(n_u, lane, alias, jac_pat);
    const q_rep = comptime repMask(n_u, lane, alias, q_pat);
    const S = DualFor(F, &lane, pad, @hasDecl(D, "collapse"));
    // Every lane of the basis: the layout the limiting correction sums in.
    const full = comptime S.Of(reads).lanes;
    const use_lim = if (comptime has_limit) limiting else false;
    const lim_writes = comptime if (has_limit) limitWritesOf(D) else 0;
    const has_q = comptime @hasDecl(D, "q");
    // `evalQ` computes both halves from one call into the model core; calling
    // `eval` and `q` separately runs the core twice.
    const fuse = comptime has_q and @hasDecl(D, "evalQ");
    // Ground predicates only on the GPU. On the host a ground stamp lands in
    // the shared trash slot/row, so the add is cheaper than the test. On the
    // GPU that add is a contended write on one address, measured 2x on 40,000
    // instances (dev/devices/gpu-evaluation.md, "One eval").
    const mask_ground = comptime SinkT.on_device;

    var id: u32 = first;
    while (id < end) : (id += 1) {
        var lx: [n_u]f64 = undefined;
        var active: [n_u]bool = undefined;
        // x minus its limited image, per lane. `canNarrow` guarantees no two
        // corrected unknowns share a lane.
        var corr: @Vector(W, f64) = @splat(0);
        inline for (0..n_u) |u| {
            const gi = sink.gath(id, u);
            active[u] = gi != GROUND;
            const xg = sink.x(gi);
            lx[u] = xg;
            // Only unknowns `limit` writes have a limited image; the other
            // lanes of `corr` stay zero.
            if (comptime has(lim_writes, u)) if (use_lim) {
                const l = sink.lim(id, u);
                lx[u] = l;
                corr[lane[u]] = xg - l;
            };
        }
        // Near convergence the limiter leaves almost every instance alone, so
        // one test skips the correction dot products.
        const corr_live = use_lim and anyNonzero(W, corr);
        const model = sink.model(id);
        const mf = mfactorOf(D, sink.inst(id));

        // `q` returns one charge per ddt site. The planes take the rows
        // (`qRows`); the host `q_tape` takes the LTE sites.
        var out: contract.Rows(D, S) = undefined;
        var qs: if (has_q) contract.Sites(D, S) else void = undefined;
        if (comptime fuse) {
            const both = @call(.always_inline, D.evalQ, .{ S, &lx, model, sink.inst(id), sim });
            out = both.res;
            qs = both.q;
        } else {
            out = D.eval(S, &lx, model, sink.inst(id), sim);
            if (comptime has_q) qs = D.q(S, &lx, model, sink.inst(id), sim);
        }
        const qo = if (comptime has_q) contract.qRows(D, S, qs) else {};

        // Rows the device never writes (`jac_row`) and entries it can never
        // fill (`jac_pat`) are dropped at comptime; the planes start at +0.0,
        // so a skipped `+= 0.0` cannot even change a sign bit. Resistive and
        // reactive halves stay in separate passes: fusing them measured
        // slower on the mos1 kernel from register pressure. A column without
        // a lane stamps its `jac_const` partial in the same (row, column)
        // order, so a shared slot sums as the tape orders it.
        inline for (0..n_u) |ru| if (comptime jac_row[ru]) if (!mask_ground or active[ru]) {
            const row = sink.rhsRow(id, ru);
            var val = out[ru].v;
            if (comptime has_limit and @TypeOf(out[ru]).lanes != 0) {
                // The correction lands on the f64 residual. A row without
                // lanes has zero gradient, so it has no correction either.
                if (corr_live) val += @reduce(.Add, head(W, out[ru].toLanes(full).grad()) * corr);
            }
            sink.scatterRes(row, val * mf);
            if (comptime !SinkT.skip_g and jac_pat[ru] != 0) {
                inline for (0..n_u) |cu| if (!mask_ground or active[cu]) {
                    if (comptime has(jac_rep[ru], cu)) {
                        sink.scatterJac(id, ru, cu, out[ru].ddxAt(cu) * mf);
                    } else if (comptime constEntry(D, ru, cu)) |e| {
                        if (comptime e.g != 0) if (contract.jacConstApplies(D, e, model, S.collapse_applied)) sink.scatterJac(id, ru, cu, e.g * mf);
                    }
                };
            }
        };

        if (comptime has_q) {
            // Gated on `q_row`, never on `q_pat`: a `ddt()` of something that
            // varies in t but not in x has a clear pattern row and a live
            // charge.
            inline for (0..n_u) |ru| if (comptime q_row[ru]) {
                const row = sink.rhsRow(id, ru);
                var qv = qo[ru].v;
                if (comptime has_limit and @TypeOf(qo[ru]).lanes != 0) {
                    if (corr_live) qv += @reduce(.Add, head(W, qo[ru].toLanes(full).grad()) * corr);
                }
                sink.scatterQ(row, qv * mf);
                if (comptime !SinkT.skip_c and q_pat[ru] != 0) {
                    if (!mask_ground or active[ru]) {
                        inline for (0..n_u) |cu| if (!mask_ground or active[cu]) {
                            if (comptime has(q_rep[ru], cu)) {
                                sink.scatterQJac(id, ru, cu, qo[ru].ddxAt(cu) * mf);
                            } else if (comptime constEntry(D, ru, cu)) |e| {
                                if (comptime e.c != 0) if (contract.jacConstApplies(D, e, model, S.collapse_applied)) sink.scatterQJac(id, ru, cu, e.c * mf);
                            }
                        };
                    }
                }
            };
            if (comptime !SinkT.on_device) inline for (comptime lteSites(D), 0..) |k, j| {
                var qv = qs[k].v;
                if (comptime has_limit and @TypeOf(qs[k]).lanes != 0) {
                    if (corr_live) qv += @reduce(.Add, head(W, qs[k].toLanes(full).grad()) * corr);
                }
                sink.tapeQ(id, j, qv * mf);
            };
        }
    }
}

/// The host pads each value's lanes to a power of two. Callgrind Ir per
/// instance, dense exact / sparse pow2, 100-instance DC sweeps:
/// hisimhv_va 23.7M/6.8M, hisim2_va 37.1M/13.7M, bsimsoi_va 7.36M/3.95M,
/// vbic13_4t 7.74M/3.83M, b3soidd 4.95M/3.02M, bsim4va 4.14M/2.32M,
/// hicumL2_va 4.53M/3.82M, gummel_poon 3.46M/1.96M, mesa 2.03M/1.58M, mos1
/// with RD/RS 1.33M/1.14M, bsim2 1.35M/0.99M, jfet 0.48M/0.37M, mes
/// 0.46M/0.34M; no wide model lost. On the narrow basis (at most 4 lanes)
/// sparse lost up to 2.8% to dense (bsim1, mos2/3/9); the dense layout went
/// with VerA 0.11's exact masks.
const host_pad = true;

/// The first `w` lanes of `v`: the unpadded basis, so the correction dot
/// product sums exactly the lanes it sums without padding.
inline fn head(comptime w: usize, v: anytype) @Vector(w, f64) {
    return @shuffle(f64, v, undefined, std.simd.iota(i32, w));
}

/// `@reduce(.Or, v != 0)` computed on the bits: true when any lane is nonzero
/// or NaN, false for ±0. Lowers to vpaddq + vptest instead of a mask shuffle.
/// Differential test against the float compare: tests/eval.zig.
inline fn anyNonzero(comptime w: usize, v: @Vector(w, f64)) bool {
    return @reduce(.Or, @as(@Vector(w, u64), @bitCast(v)) << @splat(1)) != 0;
}

/// Restamps `q_vec` and `q_tape` for instances `[first, end)` and leaves the
/// other planes alone. Host only. With `S = RealFor(...)` the charges are
/// bit-identical to a full `evalRange` pass, at no gradient cost.
///
/// The transient calls this once per accepted step: Newton returns without
/// reassembling at the accepted iterate, so the planes still hold the
/// previous iterate's charge. The limiting correction is skipped because
/// limits are cleared before Newton returns.
///
/// With `batch` non-null each instance runs `acceptQ` instead of `q`: the
/// same charges, plus the staging `updateState` does, off one core run.
fn evalQRange(comptime D: type, comptime S: type, sink: anytype, first: u32, end: u32, sim: SimState, batch: anytype) void {
    @setEvalBranchQuota(1_000_000);
    const n_u = comptime contract.nU(D);
    const q_row = comptime writtenRows(D, "q_rows");
    var id: u32 = first;
    while (id < end) : (id += 1) {
        var lx: [n_u]f64 = undefined;
        inline for (0..n_u) |u| lx[u] = sink.x(sink.gath(id, u));
        const qs = if (comptime @TypeOf(batch) == @TypeOf(null))
            D.q(S, &lx, sink.model(id), sink.inst(id), sim)
        else
            D.acceptQ(S, &lx, sink.model(id), &batch.instances[id], &batch.states[id], sim);
        const qo = contract.qRows(D, S, qs);
        const mf = mfactorOf(D, sink.inst(id));
        // Same `q_row` gate as `evalRange`, or the two passes would differ.
        inline for (0..n_u) |ru| if (comptime q_row[ru]) sink.scatterQ(sink.rhsRow(id, ru), qo[ru].v * mf);
        inline for (comptime lteSites(D), 0..) |k, j| sink.tapeQ(id, j, qs[k].v * mf);
    }
}

/// Writes back `cur[u]` for every written unknown whose limited value lies
/// within 16 ulps of the instance's largest read. At a fixed point every
/// limiter returns its probe, but a derived leg rebuilt from it (x_d = x_s +
/// vds) rounds, and that few-ulp gap would run the limiting correction at
/// every converged iterate (#49). A real clamp is orders larger.
pub inline fn snapLimited(comptime n_u: usize, comptime reads: Mask(n_u), comptime writes: Mask(n_u), lx: *[n_u]f64, cur: [n_u]f64) void {
    var scale: f64 = 0;
    inline for (0..n_u) |u| if (comptime has(reads, u)) {
        scale = @max(scale, @abs(cur[u]));
    };
    const tol = 16 * std.math.floatEps(f64) * scale;
    inline for (0..n_u) |u| if (comptime has(writes & reads, u)) {
        if (@abs(lx[u] - cur[u]) <= tol) lx[u] = cur[u];
    };
}

/// SPICE-style limiting over instances `[first, end)`: `lim = D.limit(cur,
/// old)`, where `cur` is the local x and `old` is the previous limited value
/// (once limiting is active) or the local `x_old`. Returns 1.0 when any
/// instance reports `converged = false`, which forces another Newton
/// iteration; the device decides whether its clamp was large enough.
///
/// Unknowns `limit` reads but never writes take `old` from `x_old`. That
/// equals the previous limited copy whenever `postStep` runs once per `x_old`
/// update, which holds on every CPU path (only GPU backtracking calls it
/// twice).
fn limitRange(comptime D: type, sink: anytype, first: u32, end: u32, lim_active: bool, sim: SimState) f64 {
    const n_u = comptime contract.nU(D);
    // The device's read and write sets; a MOS ladder reads 4 of its 8
    // unknowns and writes 2. All ones when the device does not declare them.
    const reads = comptime limitReadsOf(D);
    const writes = comptime limitWritesOf(D);
    // f64 rather than bool: measured +0.1% instructions with a bool here.
    var flag: f64 = 0;
    var id: u32 = first;
    while (id < end) : (id += 1) {
        // Lanes outside `reads` stay undefined: `limit` never reads them, and
        // their outputs fall outside `writes`, so nothing stores them.
        var cur: [n_u]f64 = undefined;
        var old: [n_u]f64 = undefined;
        inline for (0..n_u) |u| if (comptime has(reads, u)) {
            const gi = sink.gath(id, u);
            cur[u] = sink.x(gi);
            old[u] = if (comptime !has(writes, u))
                sink.xOld(gi)
            else if (lim_active)
                sink.lim(id, u)
            else
                sink.xOld(gi);
        };
        // A plain call on purpose. LLVM inlines it anyway; forcing
        // `.always_inline` measured 0.2-0.3% slower.
        var lm = D.limit(Real, sink.model(id), sink.inst(id), cur, old, sim);
        snapLimited(n_u, reads, writes, &lm.x, cur);
        if (!lm.converged) flag = 1;
        inline for (0..n_u) |u| if (comptime has(writes, u)) {
            sink.setLim(id, u, lm.x[u]);
        };
    }
    return flag;
}

/// Allocator for `ProtoStore` staging columns. Not the caller's allocator,
/// which is usually an arena: an arena keeps every abandoned list capacity
/// alive, measured at 73 MB on a 25,000-MOSFET deck. Separate per-column
/// lists grow by remap, never by copy, and `finalize` moves one column at a
/// time into the caller's allocator, freeing each staging column at once.
/// `core.gpa`, which this file cannot import.
const staging_gpa = if (builtin.single_threaded) std.heap.page_allocator else std.heap.smp_allocator;

/// Moves `items[k]` to `items[dst[k]]` for every k by following each cycle
/// of the permutation, one element in hand at a time. `seen` is scratch of
/// the same length; its contents on entry do not matter. O(n), no
/// allocation. Asserts that `dst` and `seen` have `items.len` entries and
/// that `dst` is a permutation of `0..items.len` (every target in range,
/// none repeated): a repeated target would otherwise walk a cycle forever
/// (#142).
pub fn permuteInPlace(comptime T: type, items: []T, dst: []const u32, seen: []bool) void {
    std.debug.assert(dst.len == items.len);
    std.debug.assert(seen.len == items.len);
    // The permutation check costs one flag write per row, against the walk's
    // one `T` swap per row, and runs once per column at freeze time.
    @memset(seen, false);
    for (dst) |d| {
        std.debug.assert(d < items.len);
        std.debug.assert(!seen[d]);
        seen[d] = true;
    }
    @memset(seen, false);
    var moved: usize = 0;
    for (0..items.len) |start| {
        if (seen[start]) continue;
        var held = items[start];
        var j = start;
        // A cycle visits each row at most once, so it closes within len steps.
        for (0..items.len) |_| {
            seen[j] = true;
            const d = dst[j];
            std.mem.swap(T, &held, &items[d]);
            moved += 1;
            j = d;
            if (j == start) break;
        } else unreachable;
    }
    std.debug.assert(moved == items.len);
}

/// Construction-time rows for one device type: each instance's Model,
/// Instance and nodes, staged until `finalize` freezes them into a
/// `DeviceBatch(D)`. Reached through the type-erased `Proto`.
pub fn ProtoStore(comptime D: type) type {
    const n_u: usize = comptime contract.nU(D);
    return struct {
        /// One entry per instance in each column, owned by `staging_gpa`.
        models: std.ArrayList(D.Model) = .empty,
        instances: std.ArrayList(D.Instance) = .empty,
        nodes: std.ArrayList([n_u]u32) = .empty,

        const Self = @This();

        /// Stages one instance. The rows live on `staging_gpa`, never the
        /// caller's allocator. On failure no column grows. Asserts that a
        /// device calling a §12.32 `$name` has its application bound
        /// (`DeviceVtable.bind_systf`): `contract.validateHost` checks the
        /// binding only in Debug, and generated code unwraps it in every mode.
        /// Reads `model` and `instance` through pointers, copied straight into
        /// the rows: a delay line's Instance carries its history (wline_4:
        /// 2 MB), and by-value temporaries of it overflowed a Debug stack.
        pub fn append(self: *Self, model: *const D.Model, instance: *const D.Instance, nodes: [n_u]u32) !void {
            if (comptime @hasDecl(D, "systf_calls") and D.systf_calls.len != 0)
                std.debug.assert(instance.systf != null);
            try self.models.ensureUnusedCapacity(staging_gpa, 1);
            try self.instances.ensureUnusedCapacity(staging_gpa, 1);
            try self.nodes.append(staging_gpa, nodes);
            self.models.addOneAssumeCapacity().* = model.*;
            self.instances.addOneAssumeCapacity().* = instance.*;
        }

        /// `Proto.pattern`: adds every (row, col) the device's structural
        /// Jacobian can fill, ground excluded. Reserving only the structural
        /// entries (25 of 64 for mos1) keeps fill-in out of every
        /// factorization.
        pub fn addPattern(ctx: *anyopaque, gpa: std.mem.Allocator, pb: *PatternBuilder) ir.DeviceResult(void) {
            return ir.DeviceResult(void).fromLocal(addPatternLocal(ctx, gpa, pb));
        }

        fn addPatternLocal(ctx: *anyopaque, gpa: std.mem.Allocator, pb: *PatternBuilder) error{OutOfMemory}!void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            const pat = comptime jacPattern(D);
            try pb.reserve(gpa, self.nodes.items.len * SlotMap(D).k);
            // Runtime loops: this runs once per batch, and unrolling n_u^2
            // for every device only costs comptime quota.
            for (self.nodes.items) |nd| {
                for (0..n_u) |ru| for (0..n_u) |cu| {
                    if (!has(pat[ru], cu)) continue;
                    if (nd[ru] != GROUND and nd[cu] != GROUND)
                        try pb.add(gpa, nd[ru], nd[cu]);
                };
            }
        }

        /// `Proto.finalize`: copies the staged rows into a new batch owned by
        /// `gpa`, builds its tapes against `pv`, and frees the staging rows.
        /// Fails with `TooManyInstances` past `maxInt(u32)` rows. On
        /// `OutOfMemory` nothing of `gpa` is left allocated, but the staging
        /// columns already moved are gone, so the store is only fit for
        /// `destroy`. Asserts that `pv` holds every non-ground (row, col)
        /// the device's structural Jacobian can fill and that `pv.col_ptr`
        /// has `pv.n + 1` entries.
        pub fn finalize(ctx: *anyopaque, gpa: std.mem.Allocator, pv: PatternView) ir.DeviceResult(Batch) {
            return ir.DeviceResult(Batch).fromLocal(finalizeLocal(ctx, gpa, pv));
        }

        fn finalizeLocal(ctx: *anyopaque, gpa: std.mem.Allocator, pv: PatternView) error{ OutOfMemory, TooManyInstances }!Batch {
            const has_q = @hasDecl(D, "q");
            const has_attempt_decl = @hasDecl(D, "attempt");
            const self: *Self = @ptrCast(@alignCast(ctx));
            // The count guard runs first: a row count past u32 fails before any
            // column or the pattern is read.
            const count = std.math.cast(u32, self.nodes.items.len) orelse return error.TooManyInstances;
            // `append` grows the three columns together.
            std.debug.assert(self.models.items.len == self.nodes.items.len);
            std.debug.assert(self.instances.items.len == self.nodes.items.len);
            std.debug.assert(pv.col_ptr.len == @as(usize, pv.n) + 1);
            const store = try gpa.create(DeviceBatch(D));

            // `create` returns undefined bytes, so every field is written here,
            // the ones with struct defaults included.
            store.count = count;
            store.sim = .{};
            store.held_initial = false;
            store.committed_initial = false;
            store.owns_tapes = true;
            store.unshared = false;
            store.models_shared = &.{};
            store.models = &.{};
            store.model_of = &.{};
            store.instances = &.{};
            store.gath = &.{};
            store.rhs_idx = &.{};
            store.slots = &.{};
            if (comptime has_q) store.q_tape = &.{};
            if (comptime has_attempt_decl) store.saved_models = &.{};
            if (comptime hasSpiceBreaks(D)) store.src_brk = &.{};
            if (comptime @hasDecl(D, "limit")) store.lim_x = &.{};
            if (comptime @hasDecl(D, "State")) store.states = &.{};
            errdefer DeviceBatch(D).hooks.deinit(store, gpa);
            // The staged rows can only be reordered before the copies below.
            if (comptime canNarrow(D)) store.narrow_count = try self.partitionCollapsed();

            // Each column moves to `gpa` at exact size and its staging copy
            // dies right after, so at most one column exists twice.
            store.model_of = try gpa.alloc(u32, count);
            const rows = if (comptime DeviceBatch(D).shares_models) try self.dedupModels(store.model_of) else blk: {
                for (store.model_of, 0..) |*row, id| row.* = @intCast(id);
                break :blk self.models.items;
            };
            store.models = try gpa.dupe(D.Model, rows);
            self.models.deinit(staging_gpa);
            self.models = .empty;
            if (comptime has_attempt_decl) {
                store.saved_models = try gpa.alloc(D.Model, count);
                store.attempt_saved = false;
            }
            if (comptime @hasDecl(D, "nextBreakpoint") and skipsTimerState(D)) store.bp = .{ .lo = std.math.inf(f64), .hi = std.math.inf(f64) };
            if (comptime hasSpiceBreaks(D)) {
                store.src_brk = try gpa.alloc(SrcBrk, count);
                @memset(store.src_brk, .{});
            }
            if (comptime @hasDecl(D, "limit")) {
                store.lim_x = try gpa.alloc(f64, count * LimMap(D).k);
                @memset(store.lim_x, 0);
                store.lim_active = false;
            }
            store.instances = try gpa.dupe(D.Instance, self.instances.items);
            self.instances.deinit(staging_gpa);
            self.instances = .empty;

            store.gath = try gpa.alloc(u32, count * n_u);
            store.rhs_idx = try gpa.alloc(u32, count * n_u);
            store.slots = try gpa.alloc(u32, count * SlotMap(D).k);
            const flat_nodes = @as([*]const u32, @ptrCast(self.nodes.items.ptr))[0 .. count * n_u];
            buildTapes(Mask(n_u), flat_nodes, n_u, &jacPattern(D), pv, store.gath, store.rhs_idx, store.slots);
            if (comptime has_q) {
                store.q_tape = try gpa.alloc(f64, count * comptime lteSites(D).len);
                @memset(store.q_tape, 0);
            }
            self.nodes.deinit(staging_gpa);
            self.nodes = .empty;

            // `setup` before `initState`: both read the card, and only the
            // former fills the row's `Model.su` (VerA device ABI 6).
            store.setupRows();
            if (comptime @hasDecl(D, "State")) {
                store.states = try gpa.alloc(D.State, count);
                for (0..count) |i| store.states[i] = D.initState(store.model(i), &store.instances[i]);
                store.commitBirth();
            }
            if (comptime @hasDecl(D, "precompute")) {
                for (0..count) |i| D.precompute(&store.instances[i], store.model(i));
            }

            // Shared rows never outnumber the instances, and any instance has one.
            std.debug.assert(store.models.len <= count);
            if (count > 0) std.debug.assert(store.models.len > 0);
            std.debug.assert(store.model_of.len == count);
            return DeviceBatch(D).binding(store);
        }

        /// Compacts the staged Models to their distinct values, in order of
        /// first use, writing each instance's row to `model_of`, and returns
        /// the distinct rows (a prefix of the staging column). Equal means
        /// bit-equal field by field: every row is first rebuilt from its
        /// fields over zeroed bytes, so padding cannot hide a match.
        fn dedupModels(self: *Self, model_of: []u32) error{OutOfMemory}![]D.Model {
            const items = self.models.items;
            for (items) |*m| canonicalize(m);
            const Ctx = struct {
                rows: []const D.Model,
                pub fn hash(_: @This(), m: *const D.Model) u32 {
                    return @truncate(std.hash.Wyhash.hash(0, std.mem.asBytes(m)));
                }
                pub fn eql(c: @This(), m: *const D.Model, row: u32, _: usize) bool {
                    return std.mem.eql(u8, std.mem.asBytes(m), std.mem.asBytes(&c.rows[row]));
                }
            };
            var seen: std.ArrayHashMapUnmanaged(u32, void, void, true) = .empty;
            defer seen.deinit(staging_gpa);
            try seen.ensureTotalCapacity(staging_gpa, items.len);
            var n: u32 = 0;
            for (items, model_of) |*m, *row| {
                const gop = seen.getOrPutAssumeCapacityAdapted(m, Ctx{ .rows = items[0..n] });
                if (!gop.found_existing) {
                    // Bytes, padding included; n <= this row, so no row
                    // still to be read is overwritten. A row already in
                    // place is left alone: @memcpy forbids overlap (#122).
                    if (&items[n] != m) @memcpy(std.mem.asBytes(&items[n]), std.mem.asBytes(m));
                    gop.key_ptr.* = n;
                    n += 1;
                }
                row.* = gop.key_ptr.*;
            }
            return items[0..n];
        }

        /// Rewrites `m` field by field over zeroed bytes.
        fn canonicalize(m: *D.Model) void {
            @setEvalBranchQuota(10 * @typeInfo(D.Model).@"struct".field_names.len + 1000);
            const copy = m.*;
            @memset(std.mem.asBytes(m), 0);
            inline for (@typeInfo(D.Model).@"struct".field_names) |name| @field(m, name) = @field(copy, name);
        }

        /// Stable-partitions the rows so maximally collapsed instances come
        /// first, and returns their count; the narrow basis is a comptime
        /// width and needs a uniform range. A uniform batch is left in place,
        /// so instance order (and slot summation order) only changes in a
        /// genuinely mixed batch.
        fn partitionCollapsed(self: *Self) !u32 {
            const len = self.nodes.items.len;
            const flags = try staging_gpa.alloc(bool, len);
            defer staging_gpa.free(flags);
            var n: usize = 0;
            for (self.models.items, self.instances.items, flags) |*m, *i, *f| {
                f.* = std.meta.eql(D.collapse(Real, m, i), D.collapse_full);
                if (f.*) n += 1;
            }
            if (n == 0 or n == len) return @intCast(n);
            // Row k moves to dst[k]; each column is permuted in place, so no
            // row is ever held twice.
            const dst = try staging_gpa.alloc(u32, len);
            defer staging_gpa.free(dst);
            var lo: u32 = 0;
            var hi: u32 = @intCast(n);
            for (flags, dst) |f, *d| {
                const next = if (f) &lo else &hi;
                d.* = next.*;
                next.* += 1;
            }
            permuteInPlace(D.Model, self.models.items, dst, flags);
            permuteInPlace(D.Instance, self.instances.items, dst, flags);
            permuteInPlace([n_u]u32, self.nodes.items, dst, flags);
            return @intCast(n);
        }

        /// `Proto.apply_perm`: renumbers staged nodes through `perm`; nodes
        /// past its end are left alone.
        pub fn applyPerm(ctx: *anyopaque, perm: []const u32) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            for (self.nodes.items) |*nd| {
                inline for (0..n_u) |u| {
                    if (nd[u] < perm.len) nd[u] = perm[nd[u]];
                }
            }
        }

        /// `Proto.destroy`: frees the staging rows and the store itself.
        pub fn destroy(ctx: *anyopaque, gpa: std.mem.Allocator) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            self.models.deinit(staging_gpa);
            self.instances.deinit(staging_gpa);
            self.nodes.deinit(staging_gpa);
            gpa.destroy(self);
        }
    };
}

/// Models whose `updateState` only advances §5.10.3 timer bookkeeping
/// (`__analog_op__timer__*`). This host never reads it: breakpoints come from
/// the model-level `nextBreakpoint`, and the pass writes `bound_step = inf`
/// and `discontinuity_order = -1`, the Instance defaults. So the batch skips
/// `updateState`, the `bound_step` walk and `stateCtl`, whose twins then
/// never differ from the Instance. Opt-in by name because a
/// `$bound_step` or `$discontinuity` call leaves no trace in the Instance:
/// vsource.va and isource.va call neither (only `$abstime` and `@(timer)`);
/// re-check before adding one. `skipsTimerState` rejects any other state.
/// Measured on tran/rc_sinusoidal_startup: ~660 Ir per step.
const timer_only_state = std.StaticStringMap(void).initComptime(.{
    .{"vsource"},
    .{"isource"},
});

fn skipsTimerState(comptime D: type) bool {
    if (timer_only_state.get(comptime baseName(D)) == null) return false;
    // Two substring scans per field name; VerA emits one field per timer.
    @setEvalBranchQuota(200_000 + 2_000 * @typeInfo(D.Instance).@"struct".field_names.len);
    for (@typeInfo(D.State).@"struct".field_names) |name| {
        if (!@hasField(D.Instance, name))
            @compileError(@typeName(D) ++ " carries State beyond stateCtl twins (" ++ name ++ "); drop it from timer_only_state");
    }
    for (@typeInfo(D.Instance).@"struct".field_names) |name| {
        if (std.mem.indexOf(u8, name, "__") != null and std.mem.indexOf(u8, name, "__analog_op__timer") == null)
            @compileError(@typeName(D) ++ " holds non-timer state (" ++ name ++ "); drop it from timer_only_state");
    }
    return true;
}

/// A source model whose PULSE and PWL corners follow ngspice's request-time
/// rounding (`spicePulseBreak`, `spicePwlBreak`) instead of VerA's timer
/// arithmetic.
fn hasSpiceBreaks(comptime D: type) bool {
    return @hasDecl(D, "nextBreakpoint") and skipsTimerState(D) and @hasField(D.Model, "pulse_td");
}

const SrcBrk = struct { req: f64 = std.math.inf(f64), at: f64 = std.math.inf(f64) };

/// Models whose ngspice load extrapolates the first Newton iterate of a
/// transient step over CKTdeltaOld[2], the step two back, where the host
/// and the other models use the previous step (hfetload.c:129). Every
/// branch voltage hfet1 reads lies between its internal nodes gp/sp/dp, so
/// re-predicting only those reproduces ngspice's and leaves the ports'
/// prediction to the other devices on them. mesaload.c:150 and
/// hfet2load.c:98 predict the same way; mesa stays off because it moved
/// tran/device_mesa_oscillator away from ngspice (52.5x -> 57.7x), and
/// hfet2 reads its gate port directly.
const delta_old2_predict = std.StaticStringMap(void).initComptime(.{.{"hfet1"}});

fn predictsOverDeltaOld2(comptime D: type) bool {
    return delta_old2_predict.get(comptime baseName(D)) != null;
}

/// Models whose ngspice load flags non-convergence itself when a branch
/// current misses its linear prediction from the previous iterate
/// (hfetload.c:389), checked host-side by `Circuit.loadCheck`. The MOS,
/// BJT and diode tests are dead in ngspice (NIiter overwrites CKTnoncon).
/// hfet2load.c:270 and mesaload.c:388 have the same test, but it moved
/// tran/device_mesa_oscillator away from ngspice (52.5x -> 65x: mesa.va's
/// series resistors are flow unknowns ngspice does not have, and their
/// delta test already adds an iteration) and op/device_hfet2 only by
/// roundoff, so both stay off.
const load_check = std.StaticStringMap(void).initComptime(.{.{"hfet1"}});

/// ngspice's PULSE breakpoint (vsrcacct.c:48-121, isrcacct.c the same): the
/// corner after `tq`, requested at the accepted time `t_acc <= tq` and
/// rounded as ngspice rounds it, `t_acc + (corner - phase(t_acc))`. VerA's
/// `td + tr + pw + tf` can land one ulp away, which moves a breakpoint across
/// an integer picosecond and changes every TXL/CPL delayed read after it
/// (txlload.c truncates time to ps). Null when the result is not after `tq`,
/// i.e. `t_acc` is not a time ngspice would have asked at, and for any
/// waveform but PULSE. Nonzero PHASE is left to the timers too: ngspice gives
/// it a different meaning outside xs mode. The widths are vsource.va's
/// P_TR/P_TF/P_PW/P_PER.
fn spicePulseBreak(m: anytype, t_acc: f64, tq: f64) ?f64 {
    if (m.waveform != 1 or m.pulse_phase != 0) return null;
    const tr = @max(m.pulse_tr, 1.0e-12);
    const tf = @max(m.pulse_tf, 1.0e-12);
    const pw = @max(m.pulse_pw, 0.0) + @max(-m.pulse_pw, 0.0) * 1.0e30;
    const per = @max(m.pulse_per, tr + pw + tf + 1.0e-12);
    var time = t_acc - m.pulse_td;
    if (time >= per) time -= per * @floor(time / per);
    // ngspice's `atime = time + CKTminBreak`; the host asks at t + minBreak.
    const atime = time + (tq - t_acc);
    const corner: f64 = if (atime < 0.0) 0.0 else if (atime < tr) tr else if (atime < tr + pw) tr + pw else if (atime < tr + pw + tf) tr + pw + tf else per;
    const bp = t_acc + (corner - time);
    return if (bp > tq) bp else null;
}

/// ngspice's PWL breakpoint for a V source (vsrcacct.c:167-216): the first
/// table time `t_k` after the request, rounded from the accepted time
/// `t_acc <= tq` as `t_acc + (t_k - local)`, where `local` is `t_acc - td`
/// folded into `[r, t_last]` by `r=`. VerA's timers give `t_k + td`, one ulp
/// away at times, and add the PULSE timers' corners at TD and TD + TR, which
/// ngspice does not have. Past the last point of a non-repeating table there
/// is no breakpoint (inf). Null when the rounded time is not after `tq`
/// (an anchor ngspice would not ask at), and for any other waveform. The
/// repeat gate is vsource.va's own, so breakpoints follow the waveform it
/// computes.
fn spicePwlBreak(m: anytype, t_acc: f64, tq: f64) ?f64 {
    const T = @TypeOf(m.*);
    if (m.waveform != 4 or m.pwl_len <= 0) return null;
    // Slot `k` of the flattened `pwl_times[]`, named as in
    // frontend/builder.zig pwlSlot.
    @setEvalBranchQuota(200_000);
    const cap = comptime blk: {
        var c: usize = 0;
        while (@hasField(T, std.fmt.comptimePrint("pwl_timesZ5b{d}Z5d", .{c}))) c += 1;
        break :blk c;
    };
    var ts: [cap]f64 = undefined;
    inline for (0..cap) |k| ts[k] = @field(m.*, std.fmt.comptimePrint("pwl_timesZ5b{d}Z5d", .{k}));
    const n: usize = @min(@as(usize, @intCast(m.pwl_len)), cap);
    const t_last = ts[n - 1];
    const r = m.pwl_repeat;
    const repeats = r >= 0.0 and n > 1 and t_last > r;
    const period = t_last - r;
    var time = t_acc - m.pwl_td;
    if (time > t_last) {
        if (!repeats) return std.math.inf(f64);
        time -= r;
        time -= period * @floor(time / period);
        time += r;
    }
    // ngspice's `atime = time + CKTminBreak`; the host asks at t + minBreak.
    const atime = time + (tq - t_acc);
    const corner = for (ts[0..n]) |c| {
        if (c > atime) break c;
    } else if (!repeats) return std.math.inf(f64) else for (ts[0..n]) |c| {
        // At the end of a repeating table ngspice sets nothing and asks again
        // one step later, after the fold; this names the same corner now.
        if (c + period > atime) break c + period;
    } else return null;
    const bp = t_acc + (corner - time);
    return if (bp > tq) bp else null;
}

/// Whether D's `updateState` pushes delay-line history, which only accepted
/// transient points may feed: LRM §4.5 `absdelay`, and the native lines that
/// declare `unrevertible_state` (they have no `stateCtl`). A VerA ring would
/// revert, but a push at the operating point seeds it with a static solve
/// (multi_analysis/bench_hb_tline_guard: 6.7e-8 to 0.66 of its tolerance).
/// VerA devices are recognized by the `__analog_op__absdelay__` infix its
/// naming scheme puts on an absdelay operator's Instance fields. A bare
/// `__absdelay__` also matches a field that merely carries the name (a
/// Verilog device's), and a device routed to `commit_state` never runs
/// `updateState` at the operating point, so its fixed point never forms.
// ponytail: field-name matching until VerA's contract marks delay history.
fn hasAbsdelayState(comptime D: type) bool {
    if (@hasDecl(D, "unrevertible_state")) return D.unrevertible_state;
    return hasInstanceField(D, "__analog_op__absdelay__");
}

/// The order `collect_noise` emits D's generators in: `gen[j]` is the
/// `noise_gens` index of output row j, and `lead[j]` the row that starts
/// its group. Rows sharing a non-null `source` are contiguous and lead by
/// the first; the rest keep declaration order.
fn noiseOrder(comptime D: type) struct { gen: [D.noise_gens.len]usize, lead: [D.noise_gens.len]u32 } {
    const gens = D.noise_gens;
    const has_source = @hasField(@typeInfo(@TypeOf(gens)).array.child, "source");
    var gen: [gens.len]usize = undefined;
    var lead: [gens.len]u32 = undefined;
    var placed: [gens.len]bool = @splat(false);
    var j: u32 = 0;
    for (gens, 0..) |g, k| {
        if (placed[k]) continue;
        const first = j;
        const src: ?u16 = if (has_source) g.source else null;
        for (gens[k..], k..) |h, m| {
            if (m != k and (src == null or h.source != src)) continue;
            placed[m] = true;
            gen[j] = m;
            lead[j] = first;
            j += 1;
        }
    }
    return .{ .gen = gen, .lead = lead };
}

/// D's §4.5.4 `idt` operator unknowns, as local indices. VerA spells the
/// k-th one `idt$k`, escaped to `idtZ24k` in `D.U`.
// ponytail: name matching, as above, until VerA's contract marks operator
// unknowns.
fn idtUnknowns(comptime D: type) []const u32 {
    comptime {
        var out: []const u32 = &.{};
        if (@hasDecl(D, "U")) for (@typeInfo(D.U).@"enum".field_names, @typeInfo(D.U).@"enum".field_values) |name, value| {
            if (std.mem.startsWith(u8, name, "idtZ24")) out = out ++ [_]u32{value};
        };
        const final = out[0..out.len].*;
        return &final;
    }
}

/// Whether the host reads D's live per-instance timer schedule
/// (`pendingBreakpoint`, which holds §5.10.3.3 start times computed during
/// the solve). Not for timer-only models, whose `updateState` never runs so
/// `__next` is stale, nor for types whose state the GPU steps
/// (`hasCtlKernel`), whose host Instance is. A host-stepped type walks.
fn walksPending(comptime D: type) bool {
    return @hasDecl(D, "pendingBreakpoint") and !skipsTimerState(D) and !hasCtlKernel(D);
}

/// Whether D's history is §5.10 held variables and no analog operator (no
/// cross/above FSM, delay line or timer).
fn holdsOnlyHeld(comptime D: type) bool {
    return hasInstanceField(D, "__held__") and !hasInstanceField(D, "__analog_op__");
}

/// Whether some Instance field of D contains `infix`.
fn hasInstanceField(comptime D: type, comptime infix: []const u8) bool {
    if (!@hasDecl(D, "Instance")) return false;
    // hisim Instances have hundreds of long field names.
    @setEvalBranchQuota(2_000_000);
    inline for (@typeInfo(D.Instance).@"struct".field_names) |name| {
        if (std.mem.indexOf(u8, name, infix) != null) return true;
    }
    return false;
}

/// The frozen per-type batch: SoA columns for every instance of D plus the
/// shared tapes, reached through `Batch` and the comptime `hooks` table. A
/// hook is null when D lacks the decl it needs.
pub fn DeviceBatch(comptime D: type) type {
    const n_u: usize = comptime contract.nU(D);
    const has_state = @hasDecl(D, "State");
    const has_q = @hasDecl(D, "q");
    const has_attempt = @hasDecl(D, "attempt");
    const has_limit = @hasDecl(D, "limit");
    const narrowable = canNarrow(D);
    // Only timer-only models: their breakpoints are pure in (model, t).
    // Native lines rewrite `Model.brk` as they step, so theirs are not.
    const has_bp = @hasDecl(D, "nextBreakpoint") and skipsTimerState(D);
    const has_src_brk = hasSpiceBreaks(D);
    // isrcacct.c requests the raw PWL table times, so only the V source
    // rounds its PWL corners.
    const is_vsource = comptime std.mem.eql(u8, baseName(D), "vsource");
    // ltra.va supplies convolution/DC; its exact dispersive AC kernel is
    // not a finite rational filter. Keep that correction on the device hook.
    const Ac = if (comptime std.mem.eql(u8, baseName(D), "ltra")) @import("ltra_ac.zig") else D;
    const has_ac_dyn = @hasDecl(Ac, "ac_dyn_slots");

    return struct {
        /// Instances whose cards bind bit-identical Models share one row of
        /// `models`. Only VerA devices, whose Model nothing but the host's
        /// parameter writes changes after `derive`; a model that caches
        /// per-instance breakpoints or rewrites itself keeps one row each.
        pub const shares_models = isVera(D) and !has_attempt and !has_bp and !has_src_brk and !@hasDecl(D, "nextBreakpoint");

        count: u32,
        /// Prepared templates own the tapes; instances made from them borrow.
        owns_tapes: bool = true,
        /// Instances `[0, narrow_count)` collapse maximally and run on the
        /// narrow basis; `ProtoStore.finalize` sorted them to the front.
        narrow_count: if (narrowable) u32 else void,
        /// One row per distinct Model (`shares_models`), else per instance.
        models: []D.Model,
        /// Per instance, its row of `models`. Owned per batch, unlike the
        /// tapes: `unshareModels` rewrites it.
        model_of: []u32,
        /// `unshareModels` replaced `models` with a `staging_gpa` copy and
        /// parked the shared rows here until `destroy`. It cannot use the
        /// batch's allocator, which the worker thread that unshares may not
        /// own (a template's is the Problem arena).
        unshared: bool,
        models_shared: []D.Model,
        saved_models: if (has_attempt) []D.Model else void,
        attempt_saved: if (has_attempt) bool else void,
        /// `nextBreakpointFn` returned `hi` (inf for none) at `lo`. That
        /// answer holds for every `t` in `[lo, hi)`: no fire lies strictly
        /// between. `lo = inf` is empty. Every model write goes through
        /// `reprep` or `applyAttempt`, which empty it.
        bp: if (has_bp) struct { lo: f64, hi: f64 } else void,
        /// Per model, ngspice's VSRCbreak_time: the PULSE or PWL breakpoint `at`
        /// requested at query time `req`, kept until a query reaches it
        /// (or goes back before `req`, a new run). `req = inf` is empty.
        src_brk: if (has_src_brk) []SrcBrk else void,
        lim_x: if (has_limit) []f64 else void,
        lim_active: if (has_limit) bool else void,
        /// The analysis state every device call receives; `eval` takes `t`
        /// from its own argument.
        sim: SimState = .{},
        /// `updateState` has latched the §5.2.1 `analog initial` results
        /// (held, §5.10), so later calls run with `analog_initial` false and
        /// skip the block. `reprep` (new parameters or temperature) clears it.
        held_initial: bool = false,
        /// `held_initial` at the last `stateCtl(.commit)`, which a
        /// `.revert` restores along with the held values it rolls back.
        committed_initial: bool = false,
        instances: []D.Instance,
        states: if (has_state) []D.State else void,
        gath: []u32,
        rhs_idx: []u32,
        slots: []u32,
        /// Charge per instance and LTE site, indexed `id * lteSites(D).len +
        /// j`. Written by `Sink.tapeQ` on the host only; see `Hooks.q_tape`.
        q_tape: if (has_q) []f64 else void,

        const Self = @This();

        const noise_order = if (@hasDecl(D, "noise_gens")) noiseOrder(D) else {};

        const noise_names = if (@hasDecl(D, "noise_gens")) blk: {
            var names: [D.noise_gens.len][]const u8 = undefined;
            for (noise_order.gen, &names) |k, *name| {
                const gen = D.noise_gens[k];
                name.* = if (@hasField(@TypeOf(gen), "name")) gen.name else "";
            }
            const frozen = names;
            break :blk frozen;
        } else {};

        /// The type's comptime hook table, shared by every batch of D. A hook
        /// is null when D lacks what it needs, so callers test the optional.
        pub const hooks: Hooks = .{
            .instantiate = instantiate,
            .snapshot = snapshot,
            .copy_state = copyState,
            .set_limit_active = if (has_limit) setLimitActive else null,
            .stage = stage,
            .scatter_tapes = scatterTapes,
            .q_tape = if (has_q) qTape else null,
            .eval_q = if (has_q) evalQOnly else null,
            // Only where `update_state` is the hook that stages (not the
            // delay lines' `commit_state`, not timer-only state).
            .accept_q = if (has_q and @hasDecl(D, "acceptQ") and !hasAbsdelayState(D) and !skipsTimerState(D)) acceptQOnly else null,
            .apply_limits = if (has_limit) applyLimits else null,
            .clear_limits = if (has_limit) clearLimits else null,
            .advance_iteration = if (@hasDecl(D, "advanceIteration")) advanceIteration else null,
            .check_convergence = if (@hasDecl(D, "checkConvergence")) checkConvergence else null,
            .predict_first_iterate = if (predictsOverDeltaOld2(D)) predictFirstIterate else null,
            .mark_load_check_rows = if (load_check.get(baseName(D)) != null) markInternalRows else null,
            .seed = if (@hasDecl(D, "seed")) seedFn else null,
            .seed_ic = if (idtUnknowns(D).len != 0) seedIc else null,
            .mark_current_rows = if (@hasDecl(D, "u_kinds")) markCurrentRows else null,
            // Delay history runs once per accepted point; everything else
            // per converged solve. See `Hooks.commit_state`.
            .update_state = if (@hasDecl(D, "updateState") and !hasAbsdelayState(D) and !skipsTimerState(D)) updateState else null,
            .commit_state = if (@hasDecl(D, "updateState") and hasAbsdelayState(D)) updateState else null,
            .state_ctl = if (@hasDecl(D, "stateCtl") and !skipsTimerState(D)) stateCtl else null,
            // Only `updateState` writes `bound_step`.
            .bound_step = if (@hasDecl(D, "updateState") and @hasField(D.Instance, "bound_step") and !skipsTimerState(D)) boundStep else null,
            .set_temp = if (@hasField(D.Model, "temperature__")) setTemp else null,
            .set_homotopy = if (@hasField(D.Model, "gmin__") or @hasField(D.Model, "source_scale__")) setHomotopy else null,
            .set_sim_state = setSimState,
            .min_delay = if (@hasDecl(D, "delays")) minDelay else null,
            .next_breakpoint = if (@hasDecl(D, "nextBreakpoint") or walksPending(D)) nextBreakpointFn else null,
            .status = if (@hasDecl(D, "status_sites")) statusFn else null,
            .say = if (@hasDecl(D, "say")) sayFn else null,
            .collect_params = collectParams,
            // A generator is only priced by the device's own `noisePsd`.
            .collect_noise = if (@hasDecl(D, "noise_gens")) blk: {
                if (!@hasDecl(D, "noisePsd")) @compileError(@typeName(D) ++
                    " declares noise_gens without noisePsd; see dev/analysis/ac-small-signal-noise.md \"Noise: the in-device convention\"");
                break :blk collectNoise;
            } else null,
            .noise_names = if (@hasDecl(D, "noise_gens")) &noise_names else &.{},
            .collect_ac_dyn = if (has_ac_dyn) collectAcDyn else null,
            .ac_dyn = if (has_ac_dyn) acDyn else null,
            .recompute = if (@hasDecl(D, "collapse") or @hasDecl(D, "precompute") or @hasDecl(D, "setup") or has_bp) recomputePrecomputed else null,
            .gpu_payload = if (gpuEligible(D)) gpuPayload else null,
            .apply_attempt = if (has_attempt) applyAttempt else null,
            .restore_models = if (has_attempt) restoreAttempt else null,
            .deinit = destroy,
        };

        fn eval(ctx: *anyopaque, pl: *const Planes, first: u32, last: u32, x: []const f64, t: f64) void {
            evalInner(ctx, pl, first, last, x, t, false, false);
        }

        /// Instance `id`'s Model.
        inline fn model(self: *const Self, id: usize) *D.Model {
            return &self.models[self.model_of[id]];
        }

        /// Gives every instance its own Model row, so a write through one
        /// instance's `ParamRef` reaches that instance alone.
        fn unshareModels(self: *Self) error{OutOfMemory}!void {
            if (self.unshared or self.models.len == self.count) return;
            const own = try staging_gpa.alloc(D.Model, self.count);
            for (own, self.model_of, 0..) |*m, row, id| {
                m.* = self.models[row];
                self.model_of[id] = @intCast(id);
            }
            self.models_shared = self.models;
            self.models = own;
            self.unshared = true;
        }

        fn evalNewton(ctx: *anyopaque, pl: *const Planes, first: u32, last: u32, x: []const f64, t: f64) void {
            evalInner(ctx, pl, first, last, x, t, true, false);
        }

        fn evalQOnly(ctx: *anyopaque, pl: *const Planes, first: u32, last: u32, x: []const f64, t: f64) void {
            evalQInner(ctx, pl, first, last, x, t, false);
        }

        fn evalQInner(ctx: *anyopaque, pl: *const Planes, first: u32, last: u32, x: []const f64, t: f64, comptime staged: bool) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            var sink = Sink(D, false, false, staged).host(self, pl, x, undefined);
            // Without `always_inline` LLVM moves mos6's charge core out of
            // line, measured +0.9% on devices/mos6_inverter.
            @call(.always_inline, evalQRange, .{ D, RealFor(@hasDecl(D, "collapse")), &sink, first, last, self.simAt(t), null });
        }

        /// `evalQOnly` at `self.sim` plus `updateState`'s staging, one core
        /// run per instance.
        fn acceptQOnly(ctx: *anyopaque, pl: *const Planes, first: u32, last: u32, x: []const f64) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            var sink = Sink(D, false, false, false).host(self, pl, x, undefined);
            @call(.always_inline, evalQRange, .{ D, RealFor(@hasDecl(D, "collapse")), &sink, first, last, self.sim, self });
        }

        fn stage(ctx: *anyopaque, pl: *const Planes, first: u32, last: u32, x: []const f64, t: f64, mode: ir.StampMode) void {
            switch (mode) {
                .full => evalInner(ctx, pl, first, last, x, t, false, true),
                .newton => evalInner(ctx, pl, first, last, x, t, true, true),
                .charge => if (comptime has_q) evalQInner(ctx, pl, first, last, x, t, true),
            }
        }

        fn scatterTapes(ctx: *anyopaque) ir.ScatterTapes {
            const self: *Self = @ptrCast(@alignCast(ctx));
            return .{ .slots = self.slots, .rows = self.rhs_idx };
        }

        fn qTape(ctx: *anyopaque) []const f64 {
            const self: *Self = @ptrCast(@alignCast(ctx));
            return self.q_tape;
        }

        fn evalInner(ctx: *anyopaque, pl: *const Planes, first: u32, last: u32, x: []const f64, t: f64, comptime skip_const: bool, comptime staged: bool) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            // Once per batch call, outside the per-instance loop.
            std.debug.assert(first <= last);
            std.debug.assert(last <= self.count);
            const limiting = if (comptime has_limit) self.lim_active else false;
            var sink = Sink(D, false, skip_const, staged).host(self, pl, x, undefined);
            const F = jacFloat(D);
            const sim = self.simAt(t);
            if (comptime narrowable) {
                // A ParEval slice may straddle the partition boundary.
                const split = std.math.clamp(self.narrow_count, first, last);
                if (split > first) evalRange(D, true, F, host_pad, &sink, first, split, sim, limiting);
                if (last > split) evalRange(D, false, F, host_pad, &sink, split, last, sim, limiting);
            } else {
                evalRange(D, false, F, host_pad, &sink, first, last, sim, limiting);
            }
        }

        /// The stored analysis state at eval time `t`.
        fn simAt(self: *const Self, t: f64) SimState {
            var sim = self.sim;
            sim.t = t;
            return sim;
        }

        fn localX(self: *Self, x: []const f64, id: usize) [n_u]f64 {
            var out: [n_u]f64 = undefined;
            inline for (0..n_u) |u| out[u] = x[self.gath[id * n_u + u]];
            return out;
        }

        fn advanceIteration(ctx: *anyopaque, previous_x: []const f64) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            for (0..self.count) |id|
                D.advanceIteration(Real, self.model(id), &self.instances[id], self.localX(previous_x, id), self.sim);
        }

        fn checkConvergence(ctx: *anyopaque, x: []const f64) bool {
            const self: *Self = @ptrCast(@alignCast(ctx));
            for (0..self.count) |id| {
                if (!D.checkConvergence(Real, self.model(id), &self.instances[id], self.localX(x, id), self.sim)) return false;
            }
            return true;
        }

        fn markInternalRows(ctx: *anyopaque, mask: []bool) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            for (0..self.count) |id| {
                inline for (D.num_ports..n_u) |u| if (comptime D.u_kinds[u] == .voltage) {
                    const row = self.gath[id * n_u + u];
                    if (row != GROUND) mask[row] = true;
                };
            }
        }

        fn predictFirstIterate(ctx: *anyopaque, trial: []f64, cur: []const f64, prev: []const f64, xfact: f64) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            for (0..self.count) |id| {
                inline for (D.num_ports..n_u) |u| if (comptime D.u_kinds[u] == .voltage) {
                    const row = self.gath[id * n_u + u];
                    if (row != GROUND) trial[row] = cur[row] + xfact * (cur[row] - prev[row]);
                };
            }
        }

        fn seedFn(ctx: *anyopaque, x: []f64) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            if (comptime has_limit) {
                // Only the slots `limitRange` maintains are ever read back.
                const writes = comptime limitWritesOf(D);
                for (0..self.count) |id| {
                    const sv = D.seed(Real, self.model(id), &self.instances[id], self.sim);
                    inline for (0..n_u) |u| if (comptime has(writes, u)) {
                        self.lim_x[id * LimMap(D).k + comptime LimMap(D).at(u)] = sv[u] orelse x[self.gath[id * n_u + u]];
                    };
                }
                self.lim_active = true;
            }
        }

        fn seedIc(ctx: *anyopaque, x: []f64) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            const R = RealFor(@hasDecl(D, "collapse"));
            for (0..self.count) |id| inline for (comptime idtUnknowns(D)) |u| {
                const gi = self.gath[id * n_u + u];
                if (gi != GROUND) {
                    // The static row is s - ic when the idt has an ic (slope
                    // 1) and does not read s otherwise (slope 0). One exact
                    // Newton step on the row lands s on ic.
                    var lx = self.localX(x, id);
                    const r0 = D.eval(R, &lx, self.model(id), &self.instances[id], self.sim)[u].v;
                    lx[u] += 1.0;
                    const slope = D.eval(R, &lx, self.model(id), &self.instances[id], self.sim)[u].v - r0;
                    if (slope != 0) x[gi] -= r0 / slope;
                }
            };
        }

        /// Marks the rows of non-voltage unknowns (branch currents) unless the
        /// same node is also one of the instance's voltage unknowns.
        fn markCurrentRows(ctx: *anyopaque, mask: []bool) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            // Runtime loops: n_u^2 unrolled overflows the quota past 64 unknowns.
            for (0..self.count) |id| {
                const nd = self.gath[id * n_u ..][0..n_u];
                for (nd, D.u_kinds) |node, kind| {
                    if (kind == .voltage or node == GROUND) continue;
                    const voltage_alias = for (nd, D.u_kinds) |other, k| {
                        if (k == .voltage and other == node) break true;
                    } else false;
                    if (!voltage_alias) mask[node] = true;
                }
            }
        }

        fn applyLimits(ctx: *anyopaque, x: []f64, x_old: []const f64) bool {
            const self: *Self = @ptrCast(@alignCast(ctx));
            // `limitRange` never touches the planes, but `host` reads their
            // pointers, and `undefined` would trap in Debug.
            const no_planes: Planes = .{ .g_vals = &.{}, .c_vals = &.{}, .rhs = &.{}, .q_vec = &.{} };
            var sink = Sink(D, false, false, false).host(self, &no_planes, x, x_old.ptr);
            const any = limitRange(D, &sink, 0, @intCast(self.count), self.lim_active, self.sim);
            self.lim_active = true;
            return any != 0;
        }

        fn clearLimits(ctx: *anyopaque) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            self.lim_active = false;
        }

        /// Runs `D.updateState` on every instance at `x` and returns the
        /// earliest time any of them asks the step to be rejected at, if any.
        /// Called once per converged solve (or per accepted step for
        /// `commit_state`), not per Newton iteration.
        fn updateState(ctx: *anyopaque, x: []const f64) ?f64 {
            const self: *Self = @ptrCast(@alignCast(ctx));
            var min_reject: ?f64 = null;
            for (0..self.count) |id| {
                const lx = self.localX(x, id);
                switch (D.updateState(Real, self.model(id), &self.instances[id], lx, &self.states[id], self.sim)) {
                    .ok => {},
                    .request_reject_at => |tr| {
                        min_reject = if (min_reject) |cur| @min(cur, tr) else tr;
                    },
                }
            }
            self.held_initial = true;
            self.sim.analog_initial = false;
            return min_reject;
        }

        /// Values one `say` call can record: every site once, or 256, so a
        /// task in a loop has room too. More counts as lost (`formatSay`).
        const say_len = if (@hasDecl(D, "say")) blk: {
            var n: usize = 0;
            for (D.say_sites) |site| n += 1 + site.nargs;
            break :blk @max(n, 256);
        } else 0;

        /// `Hooks.say`: instance `id`'s display tasks at x, rendered to `w`.
        /// Reads the host Instance copy; a device with `say` is never
        /// resident (the built-ins are generated without it).
        fn sayFn(ctx: *anyopaque, x: []const f64, id: u32, name: []const u8, w: *std.Io.Writer) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            std.debug.assert(id < self.count);
            var buf: [say_len]f64 = undefined;
            var out: contract.Say = .{ .buf = &buf };
            const lx = self.localX(x, id);
            D.say(Real, &lx, self.model(id), &self.instances[id], self.sim, &out);
            std.debug.assert(out.len <= buf.len);
            contract.formatSay(D, &out, name, w) catch {}; // a failed writer drops the text
        }

        /// `Hooks.status`. Reads the host Instance copy; for a resident batch
        /// the GPU launcher downloads it first (`GpuContext.syncStatus`).
        fn statusFn(ctx: *anyopaque, msg: []u8) ?ir.StatusHit {
            const self: *Self = @ptrCast(@alignCast(ctx));
            for (self.instances[0..self.count], 0..) |*inst, i| {
                if (inst.vera_status__ == 0) continue;
                var w: std.Io.Writer = .fixed(msg);
                contract.formatStatus(D, inst, &w) catch {}; // a full buffer truncates
                return .{ .index = @intCast(i), .len = @intCast(w.end) };
            }
            return null;
        }

        /// Tightest `$bound_step` across this batch's instances. Read after an
        /// accepted step, so `updateState` has already refreshed every one.
        fn boundStep(ctx: *anyopaque) f64 {
            const self: *Self = @ptrCast(@alignCast(ctx));
            var b = std.math.inf(f64);
            for (self.instances[0..self.count]) |*inst| b = @min(b, inst.bound_step);
            return b;
        }

        /// Commits the initial state, so a `stateCtl(.revert)` before the
        /// first accepted point restores it rather than the `State` defaults.
        fn commitBirth(self: *Self) void {
            if (comptime @hasDecl(D, "stateCtl")) _ = stateCtl(self, .commit);
        }

        fn stateCtl(ctx: *anyopaque, op: StateCtlOp) bool {
            const self: *Self = @ptrCast(@alignCast(ctx));
            var dirty = false;
            for (0..self.count) |id| {
                if (D.stateCtl(self.model(id), &self.instances[id], &self.states[id], @fromBackingInt(@intCast(@backingInt(op))))) dirty = true;
            }
            switch (op) {
                .commit => self.committed_initial = self.held_initial,
                .revert => {
                    self.held_initial = self.committed_initial;
                    self.sim.analog_initial = !self.held_initial;
                },
                .query => {},
            }
            return dirty;
        }

        /// Sets every Model row's temperature from Celsius (`.temp`) to the
        /// Kelvin `$temperature` reads (LRM §9.10), then reruns `setup` and
        /// `precompute`. Rows stay rows: every one gets the same value.
        fn setTemp(ctx: *anyopaque, temp_c: f32) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            for (self.models) |*m| m.temperature__ = @as(f64, temp_c) + 273.15;
            self.reprep();
        }

        /// Writes the §9.15 homotopy knobs into every Model row, then reruns
        /// `setup` when it caches either one (VerA `setup_simparams`).
        /// Parameter defaults derived from them keep their build-time value.
        fn setHomotopy(ctx: *anyopaque, gmin: f64, source_scale: f64) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            for (self.models) |*m| {
                if (comptime @hasField(D.Model, "gmin__")) m.gmin__ = gmin;
                if (comptime @hasField(D.Model, "source_scale__")) m.source_scale__ = source_scale;
            }
            const cached = comptime if (@hasDecl(D, "setup_simparams")) blk: {
                for (D.setup_simparams) |n| {
                    if (std.mem.eql(u8, n, "gmin") or std.mem.eql(u8, n, "sourceScaleFactor")) break :blk true;
                }
                break :blk false;
            } else false;
            if (cached) {
                self.setupRows();
                if (comptime @hasDecl(D, "precompute")) {
                    for (self.instances, 0..) |*inst, id| D.precompute(inst, self.model(id));
                }
            }
        }

        fn setSimState(ctx: *anyopaque, st: SimState) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            self.sim = st;
            if (self.held_initial) self.sim.analog_initial = false;
        }

        fn applyAttempt(ctx: *anyopaque, lambda: f64) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            if (!self.attempt_saved) {
                @memcpy(self.saved_models, self.models);
                self.attempt_saved = true;
            }
            for (self.models, self.saved_models) |*m, s| m.* = D.attempt(s, lambda);
            if (comptime has_bp) self.bp.lo = std.math.inf(f64);
            self.reprep();
        }

        fn restoreAttempt(ctx: *anyopaque) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            if (!self.attempt_saved) return;
            self.attempt_saved = false;
            @memcpy(self.models, self.saved_models);
            self.reprep();
        }

        /// This batch's GPU working set. The slices stay owned by the batch.
        fn gpuPayload(ctx: *anyopaque) GpuPayload {
            const self: *Self = @ptrCast(@alignCast(ctx));
            return .{
                .kernel = comptime kernelName(D),
                .count = self.count,
                .n_u = n_u,
                .models = std.mem.sliceAsBytes(self.models),
                .model_of = self.model_of,
                .instances = std.mem.sliceAsBytes(self.instances),
                .gath = self.gath,
                .rhs_idx = self.rhs_idx,
                .slots = self.slots,
                .lim_kernel = comptime if (hasStateKernel(D)) stateKernelName(D) else "",
                .ctl_kernel = comptime if (hasCtlKernel(D)) ctlKernelName(D) else "",
                .reduce_kernel = comptime reduceKernelName(D),
                .lim_x = if (comptime has_limit) self.lim_x else &.{},
                .states = if (comptime has_state) std.mem.sliceAsBytes(self.states) else &.{},
                .lim_active = if (comptime has_limit) self.lim_active else false,
            };
        }

        /// Reruns `setup` and `precompute` and returns false when `collapse` now asks for
        /// a node aliasing the frozen tapes do not have.
        fn recomputePrecomputed(ctx: *anyopaque) bool {
            const self: *Self = @ptrCast(@alignCast(ctx));
            self.reprep();
            if (comptime @hasDecl(D, "collapse")) {
                for (self.instances, 0..) |*inst, id| {
                    const col = D.collapse(Real, self.model(id), inst);
                    const nd = self.gath[id * n_u ..][0..n_u];
                    inline for (D.num_ports..n_u) |u| {
                        if (col[u]) |target| {
                            if (nd[u] != nd[target]) return false;
                        } else if (std.mem.indexOfScalar(u32, nd[0..u], nd[u]) != null) {
                            // The builder gave every unaliased internal its own node.
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        fn reprep(self: *Self) void {
            self.held_initial = false;
            self.sim.analog_initial = true;
            if (comptime has_bp) self.bp.lo = std.math.inf(f64);
            if (comptime has_src_brk) @memset(self.src_brk, .{});
            self.setupRows();
            if (comptime @hasDecl(D, "precompute")) {
                for (self.instances, 0..) |*inst, id| D.precompute(inst, self.model(id));
            }
        }

        /// VerA's `setup` once per Model row (the solve-invariant cache and
        /// the temperature live on the row, VerA device ABI 6), then
        /// `setupInstance` for every instance that caches from its row.
        fn setupRows(self: *Self) void {
            if (comptime @hasDecl(D, "setup")) for (self.models) |*m| D.setup(Real, m);
            if (comptime @hasDecl(D, "setupInstance")) for (self.instances, 0..) |*inst, id| D.setupInstance(self.model(id), inst);
        }

        fn minDelay(ctx: *anyopaque) f64 {
            const self: *Self = @ptrCast(@alignCast(ctx));
            var min_td = std.math.inf(f64);
            for (self.models) |*m| {
                for (D.delays(m)) |d| min_td = @min(min_td, d);
            }
            return min_td;
        }

        /// The earliest model or instance breakpoint strictly after `t`. The
        /// transient asks once per step; for a timer-only model (`has_bp`)
        /// the answer only moves when `t` reaches it, so the walk (68 timers
        /// per vsource model, ~425 Ir) runs once per breakpoint instead. A
        /// PULSE or V-source PWL corner rounds from the accepted time `sim.t`
        /// (the transient asks right after accepting it), as ngspice's
        /// VSRCaccept does.
        fn nextBreakpointFn(ctx: *anyopaque, t: f64) ?f64 {
            const self: *Self = @ptrCast(@alignCast(ctx));
            if (comptime has_bp) {
                if (self.bp.lo <= t and t < self.bp.hi) return if (self.bp.hi == std.math.inf(f64)) null else self.bp.hi;
            }
            const t_acc = if (self.sim.kind == .tran and self.sim.t <= t) self.sim.t else t;
            var best: f64 = std.math.inf(f64);
            if (comptime @hasDecl(D, "nextBreakpoint")) for (self.models, 0..) |*m, i| {
                if (comptime has_src_brk) {
                    const b = &self.src_brk[i];
                    if (t < b.req or t >= b.at)
                        b.* = .{ .req = t, .at = spicePulseBreak(m, t_acc, t) orelse
                            (if (comptime is_vsource) spicePwlBreak(m, t_acc, t) else null) orelse
                            D.nextBreakpoint(m, t) orelse std.math.inf(f64) };
                    best = @min(best, b.at);
                    continue;
                }
                if (D.nextBreakpoint(m, t)) |bp| best = @min(best, bp);
            };
            // §5.10.3.3 re-armed fire times exist only in the committed
            // Instance, so every commit can move them: no cache.
            if (comptime walksPending(D)) for (self.instances) |*inst| {
                if (D.pendingBreakpoint(inst, t)) |bp| best = @min(best, bp);
            };
            if (comptime has_bp) self.bp = .{ .lo = t, .hi = best };
            return if (best == std.math.inf(f64)) null else best;
        }

        fn collectParams(ctx: *anyopaque, gpa: std.mem.Allocator, list: *std.ArrayList(ParamRef)) ir.DeviceResult(void) {
            return ir.DeviceResult(void).fromLocal(collectParamsLocal(ctx, gpa, list));
        }

        fn collectParamsLocal(ctx: *anyopaque, gpa: std.mem.Allocator, list: *std.ArrayList(ParamRef)) error{OutOfMemory}!void {
            // `paramField` runs per field; txl's history has ~10k fields.
            @setEvalBranchQuota(100_000 + 100 * (@typeInfo(D.Instance).@"struct".field_names.len + @typeInfo(D.Model).@"struct".field_names.len));
            const self: *Self = @ptrCast(@alignCast(ctx));
            try self.unshareModels();
            try appendParams(D.Instance, self.instances, true, gpa, list);
            try appendParams(D.Model, self.models, false, gpa, list);
        }

        fn appendParams(comptime T: type, items: anytype, comptime is_instance: bool, gpa: std.mem.Allocator, list: *std.ArrayList(ParamRef)) error{OutOfMemory}!void {
            comptime var field_idx: usize = 0;
            inline for (@typeInfo(T).@"struct".field_names) |field_name| {
                if (comptime paramField(T, field_name)) {
                    const primary = comptime if (@hasDecl(D, "mc_param"))
                        std.mem.eql(u8, field_name, D.mc_param)
                    else if (isVera(D))
                        !is_instance and field_idx == 0
                    else
                        is_instance and field_idx == 0;
                    for (items, 0..) |*it, idx| {
                        try list.append(gpa, .{
                            .ptr = if (@FieldType(T, field_name) == f32)
                                .{ .f32 = &@field(it, field_name) }
                            else
                                .{ .f64 = &@field(it, field_name) },
                            .param_name = field_name,
                            .index = @intCast(idx),
                            .is_instance = is_instance,
                            .primary = primary,
                        });
                    }
                    field_idx += 1;
                }
            }
        }

        /// Whether field `field_name` of T is a sweepable parameter: a float with a
        /// finite default that is not a VerA-internal or runtime-state field.
        fn paramField(comptime T: type, comptime field_name: []const u8) bool {
            if (@FieldType(T, field_name) != f32 and @FieldType(T, field_name) != f64) return false;
            // A trailing `__` is VerA's own namespace (no escaped Verilog-A
            // name ends in `_`), e.g. `nom_temp__` from `.options tnom`,
            // which `.mc`/`.sens` must not perturb. So is `<flow>__retained`,
            // the retention flag `derive` writes (contract `JacWhen`).
            if (comptime std.mem.endsWith(u8, field_name, "__") or
                std.mem.endsWith(u8, field_name, "__retained")) return false;
            if (isVera(D) and T == D.Instance) {
                // A VerA Instance holds runtime state; only `mfactor` is a
                // parameter (the temperature is the Model row's
                // `temperature__`, VerA device ABI 6).
                if (!std.mem.eql(u8, field_name, "mfactor")) return false;
            }
            const dflt = @field(T{}, field_name);
            return dflt > -1e30 and dflt < 1e30;
        }

        /// Appends one `NoiseSource` per declared generator per instance, with
        /// the PSD `D.noisePsd` gives at `x`. Pure in `x`, so `.pnoise` can
        /// call it once per PSS sample.
        fn collectNoise(ctx: *anyopaque, x: []const f64, gpa: std.mem.Allocator, list: *std.ArrayList(NoiseSource)) ir.DeviceResult(void) {
            return ir.DeviceResult(void).fromLocal(collectNoiseLocal(ctx, x, gpa, list));
        }

        fn collectNoiseLocal(ctx: *anyopaque, x: []const f64, gpa: std.mem.Allocator, list: *std.ArrayList(NoiseSource)) error{OutOfMemory}!void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            try list.ensureUnusedCapacity(gpa, self.count * D.noise_gens.len);
            for (0..self.count) |id| {
                const base: u32 = @intCast(list.items.len);
                const terms = D.noisePsd(NoiseFamily(D), self.localX(x, id), self.model(id), &self.instances[id], self.sim);
                // m copies are m independent generators: m times the power.
                // A table row's PSD is the table, so its amplitude takes sqrt(m).
                const mf = mfactorOf(D, &self.instances[id]);
                // Rows go out in `noise_order`, so a correlated generator's
                // rows are contiguous. Term k belongs to generator k
                // (noise-contract.md §3). `@abs` matches ngspice
                // nevalsrc.c:106. Zero-power generators stay: their ordinal
                // identifies them across PSS samples. A (u, u) branch is u to
                // ground.
                inline for (noise_order.gen, noise_order.lead) |k, lead| {
                    const gen = D.noise_gens[k];
                    const t = terms[k];
                    const table = comptime if (@hasField(@TypeOf(gen), "table")) gen.table else null;
                    list.appendAssumeCapacity(.{
                        .node_p = self.gath[id * n_u + gen.row],
                        .node_n = if (gen.row == gen.col) GROUND else self.gath[id * n_u + gen.col],
                        .white = @abs(t.white) * mf,
                        .flicker = @abs(t.flicker) * mf,
                        .ef = t.ef,
                        .coeff = if (table != null) t.coeff * @sqrt(mf) else t.coeff,
                        .group = base + lead,
                        .table = if (table) |i| D.noise_tables[i] else .{ .interp = .linear, .points = &.{} },
                    });
                }
            }
        }

        fn collectAcDyn(ctx: *anyopaque, gpa: std.mem.Allocator, list: *std.ArrayList(u32)) ir.DeviceResult(void) {
            const self: *Self = @ptrCast(@alignCast(ctx));
            list.ensureUnusedCapacity(gpa, self.count * Ac.ac_dyn_slots.len) catch return .out_of_memory;
            const k = SlotMap(D).k;
            const pos = comptime blk: {
                @setEvalBranchQuota(10_000_000);
                var p: [Ac.ac_dyn_slots.len]u32 = undefined;
                for (&p, Ac.ac_dyn_slots) |*o, s| o.* = SlotMap(D).at(s / n_u, s % n_u);
                break :blk p;
            };
            for (0..self.count) |id| {
                for (pos) |p| list.appendAssumeCapacity(self.slots[id * k + p]);
            }
            return .{ .ok = {} };
        }

        /// `Hooks.ac_dyn`: one `Ac.acDyn` call per instance and lane-width
        /// chunk of `omegas`, a ragged tail padded with its last ω.
        fn acDyn(ctx: *anyopaque, x: []const f64, omegas: []const f64, re: []f64, im: []f64) usize {
            const self: *Self = @ptrCast(@alignCast(ctx));
            const K = Ac.ac_dyn_slots.len;
            const LW = std.simd.suggestVectorLength(f64) orelse 1;
            const V = @Vector(LW, f64);
            const nw = omegas.len;
            const sim = self.sim;
            for (0..self.count) |id| {
                const lx = self.localX(x, id);
                var j: usize = 0;
                while (j < nw) : (j += LW) {
                    const cnt = @min(LW, nw - j);
                    var ow: [LW]f64 = undefined;
                    for (0..LW) |l| ow[l] = omegas[j + @min(l, cnt - 1)];
                    var out: [K]std.math.Complex(V) = undefined;
                    Ac.acDyn(V, self.model(id), &self.instances[id], &lx, sim, ow, &out);
                    const mf: V = @splat(mfactorOf(D, &self.instances[id]));
                    for (out, 0..) |o, k| {
                        const e = (id * K + k) * nw + j;
                        const r: [LW]f64 = o.re * mf;
                        const i: [LW]f64 = o.im * mf;
                        @memcpy(re[e..][0..cnt], r[0..cnt]);
                        @memcpy(im[e..][0..cnt], i[0..cnt]);
                    }
                }
            }
            return self.count * K;
        }

        fn binding(self: *Self) Batch {
            const const_g = @hasDecl(D, "constant") and D.constant.g;
            const const_c = @hasDecl(D, "constant") and D.constant.c;
            return .{
                .ctx = self,
                .eval = eval,
                .eval_newton = evalNewton,
                .count = self.count,
                .n_u = n_u,
                .has_charge = has_q,
                .has_const_jacobian = const_g and (!has_q or const_c),
                .type_name = comptime baseName(D),
                .hooks = &hooks,
            };
        }

        fn instantiate(ctx: *const anyopaque, gpa: std.mem.Allocator) ir.DeviceResult(Batch) {
            return ir.DeviceResult(Batch).fromLocal(duplicate(ctx, gpa, false));
        }

        fn snapshot(ctx: *const anyopaque, gpa: std.mem.Allocator) ir.DeviceResult(Batch) {
            return ir.DeviceResult(Batch).fromLocal(duplicate(ctx, gpa, true));
        }

        fn copyState(dst_ctx: *anyopaque, src_ctx: *const anyopaque) void {
            const dst: *Self = @ptrCast(@alignCast(dst_ctx));
            const src: *const Self = @ptrCast(@alignCast(src_ctx));
            // Either side may have been unshared since the copy was made.
            if (dst.models.len == src.models.len) {
                @memcpy(dst.models, src.models);
            } else for (0..dst.count) |id| {
                dst.model(id).* = src.model(id).*;
            }
            @memcpy(dst.instances, src.instances);
            if (comptime has_state) @memcpy(dst.states, src.states);
            if (comptime has_q) @memcpy(dst.q_tape, src.q_tape);
            if (comptime has_attempt) {
                @memcpy(dst.saved_models, src.saved_models);
                dst.attempt_saved = src.attempt_saved;
            }
            if (comptime has_limit) {
                @memcpy(dst.lim_x, src.lim_x);
                dst.lim_active = src.lim_active;
            }
            if (comptime has_bp) dst.bp = src.bp;
            if (comptime has_src_brk) @memcpy(dst.src_brk, src.src_brk);
            dst.held_initial = src.held_initial;
            dst.committed_initial = src.committed_initial;
            dst.sim.analog_initial = !dst.held_initial;
        }

        fn setLimitActive(ctx: *anyopaque, active: bool) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            self.lim_active = active;
        }

        /// A new batch sharing the template's tapes with private copies of
        /// all mutable state. `accepted` copies the template's history
        /// (`snapshot`); otherwise history starts fresh (`instantiate`).
        fn duplicate(ctx: *const anyopaque, gpa: std.mem.Allocator, comptime accepted: bool) !Batch {
            const template: *const Self = @ptrCast(@alignCast(ctx));
            const self = try gpa.create(Self);
            self.* = template.*;
            self.owns_tapes = false;
            self.unshared = false;
            self.models_shared = &.{};
            if (!accepted) {
                self.held_initial = false;
                self.committed_initial = false;
                self.sim.analog_initial = true;
            }
            self.models = &.{};
            self.model_of = &.{};
            self.instances = &.{};
            if (comptime has_state) self.states = &.{};
            if (comptime has_q) self.q_tape = &.{};
            if (comptime has_attempt) {
                self.saved_models = &.{};
                self.attempt_saved = if (accepted) template.attempt_saved else false;
            }
            if (comptime has_limit) {
                self.lim_x = &.{};
                self.lim_active = if (accepted) template.lim_active else false;
            }
            if (comptime has_src_brk) self.src_brk = &.{};
            errdefer destroy(self, gpa);

            // Model/Instance are POD, so a byte copy is a deep copy.
            self.models = try gpa.dupe(D.Model, template.models);
            self.model_of = try gpa.dupe(u32, template.model_of);
            self.instances = try gpa.dupe(D.Instance, template.instances);
            if (comptime has_src_brk) self.src_brk = try gpa.dupe(SrcBrk, template.src_brk);
            if (comptime has_attempt) {
                self.saved_models = try gpa.alloc(D.Model, self.count);
                if (accepted and template.attempt_saved) @memcpy(self.saved_models, template.saved_models);
            }
            if (comptime has_limit) {
                self.lim_x = try gpa.alloc(f64, self.count * LimMap(D).k);
                if (accepted) @memcpy(self.lim_x, template.lim_x) else @memset(self.lim_x, 0);
            }
            if (comptime has_q) {
                self.q_tape = try gpa.alloc(f64, self.count * comptime lteSites(D).len);
                if (accepted) @memcpy(self.q_tape, template.q_tape) else @memset(self.q_tape, 0);
            }
            if (comptime has_state) {
                self.states = try gpa.alloc(D.State, self.count);
                if (accepted) {
                    @memcpy(self.states, template.states);
                } else {
                    for (self.states, self.instances, 0..) |*state, *instance, id|
                        state.* = D.initState(self.model(id), instance);
                    self.commitBirth();
                }
            }
            return self.binding();
        }

        fn destroy(ctx: *anyopaque, gpa: std.mem.Allocator) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            if (self.unshared) {
                staging_gpa.free(self.models);
                gpa.free(self.models_shared);
            } else gpa.free(self.models);
            gpa.free(self.model_of);
            if (comptime has_attempt) gpa.free(self.saved_models);
            if (comptime has_limit) gpa.free(self.lim_x);
            if (comptime has_src_brk) gpa.free(self.src_brk);
            gpa.free(self.instances);
            if (comptime has_state) gpa.free(self.states);
            if (self.owns_tapes) {
                gpa.free(self.gath);
                gpa.free(self.rhs_idx);
                gpa.free(self.slots);
            }
            if (comptime has_q) gpa.free(self.q_tape);
            gpa.destroy(self);
        }
    };
}

/// Whether VerA generated D (every VerA device declares `lane_masks`; the
/// hand-written ones do not). A VerA Instance holds runtime state beside its
/// two parameters.
fn isVera(comptime D: type) bool {
    return @hasDecl(D, "lane_masks");
}

/// Whether D gets GPU kernels. Excluded, and kept on the host:
/// - `mutable_eval` devices, whose first-call snapshots need exclusive
///   evaluation, unless the status latch and timepoint cache are their only
///   eval writes (`statusOnlyMutable`);
/// - Newton-history devices (`advanceIteration`/`checkConvergence`), whose
///   `limiter_previous` the host advances on its own Instance copy;
/// - devices with `systf_calls`, whose `Instance.systf` is a host function
///   pointer (LRM §12.32) a GPU thread cannot call.
///
/// `State` without `limit` that VerA does not declare `.path_latch` (the
/// `.history` class: switches, delay lines, Laplace and pole filters) is
/// admitted host-stepped (`gpuHostStepped`).
/// A path latch (`state_class == .path_latch`, or `State` with `limit`) is
/// what `StateKernel` and `CtlKernel` run on the device: `updateState`
/// stages `wb__/wq__`, `stateCtl` commits them into the `pb__/pq__` latches
/// eval reads. A held device's `State` is that latch plus its held
/// variables, all in the resident Instance. Every `StateKernel` runs the
/// limit half per iterate and the state half once per converged solve
/// (#15), so no Newton iterate is latched. `SimState` is a
/// kernel argument, so a core that reads `analysis()` or `$abstime` (the
/// Meyer MOS models, jfet2) runs resident too.
// ponytail: the State-with-limit rule is decl correlation, not proof;
// `StateKernel` flags any non-`.ok` `updateState` so a device that breaks it
// falls back to the CPU instead of running wrong.
fn gpuEligible(comptime D: type) bool {
    return gpuRefusal(D) == null;
}

/// Why `gpuEligible` turns D down, one tag per rule above in order. The
/// inventory test in tests/eval.zig pins it per built-in model.
const GpuRefusal = enum { mutable_eval, newton_history, systf };

fn gpuRefusal(comptime D: type) ?GpuRefusal {
    if (@hasDecl(D, "mutable_eval") and D.mutable_eval and !statusOnlyMutable(D)) return .mutable_eval;
    if (@hasDecl(D, "advanceIteration") or @hasDecl(D, "checkConvergence")) return .newton_history;
    if (@hasDecl(D, "systf_calls") and D.systf_calls.len != 0) return .systf;
    return null;
}

/// Whether D evaluates on the device but steps its state on the host: its
/// `State` is `.history` (no `limit`, no held variables, not a path
/// latch), so `updateState`, `commit_state` and `stateCtl` walk the host
/// Instance, where step control reads breakpoints and `$bound_step`, and
/// the GPU context uploads the rows they change before the next eval
/// (`GpuContext.pushStepped`). No state or control kernel.
fn gpuHostStepped(comptime D: type) bool {
    if (!gpuEligible(D) or holdsOnlyHeld(D)) return false;
    if (@hasDecl(D, "limit") or !@hasDecl(D, "State")) return false;
    return !(@hasDecl(D, "state_class") and D.state_class == .path_latch);
}

/// Whether D's eval writes only its own instance: VerA's §9.7.3 status
/// latch (`status_sites`) and/or its `vera_timepoint` cache (`tp0_t`; ltra
/// has the cache and no latch), which a device thread writes on its
/// resident Instance as the host does. §9.21.1 table state (`table_ready`)
/// keeps the device on the host.
fn statusOnlyMutable(comptime D: type) bool {
    const latch_or_cache = @hasDecl(D, "status_sites") or @hasField(D.Instance, "tp0_t");
    return latch_or_cache and !@hasField(D.Instance, "table_ready");
}

/// Whether D's GPU eval kernel is paired with a `StateKernel`.
fn hasStateKernel(comptime D: type) bool {
    return gpuEligible(D) and (@hasDecl(D, "limit") or @hasDecl(D, "State")) and !gpuHostStepped(D);
}

/// Whether D also needs a `CtlKernel`: `stateCtl` mutates the resident
/// Instance/State blobs, which the host cannot reach.
fn hasCtlKernel(comptime D: type) bool {
    return hasStateKernel(D) and @hasDecl(D, "stateCtl");
}

/// D's type name without its namespace (`vsource.Vsource` gives `Vsource`).
/// Used as the batch `type_name` and the kernel symbol suffix.
fn baseName(comptime D: type) []const u8 {
    const full = @typeName(D);
    const dot = std.mem.lastIndexOfScalar(u8, full, '.') orelse return full;
    return full[dot + 1 ..];
}

// Kernel symbols, derived from the type so the build root that exports them
// and `gpuPayload` that names them for the launcher cannot drift apart.

fn kernelName(comptime D: type) [:0]const u8 {
    return "arp_eval_" ++ comptime baseName(D);
}

fn stateKernelName(comptime D: type) [:0]const u8 {
    return "arp_lim_" ++ comptime baseName(D);
}

fn ctlKernelName(comptime D: type) [:0]const u8 {
    return "arp_ctl_" ++ comptime baseName(D);
}

/// The reduce body is device-independent, but gompute needs kernel names
/// unique across the per-device build roots, so each device exports a copy.
fn reduceKernelName(comptime D: type) [:0]const u8 {
    return "arp_reduce_" ++ comptime baseName(D);
}

/// Not carried in the frozen `GpuPayload`: the host derives it from
/// `kernelName`, so the prefix swap there must match this.
/// Lane kernel symbols, named from `kernelName` by the host
/// (`gpu_lanes.laneName`), not carried in the frozen `GpuPayload`.
fn laneKernelName(comptime D: type, comptime what: []const u8) [:0]const u8 {
    return "arp_l" ++ what ++ "_" ++ comptime baseName(D);
}

fn qTapeKernelName(comptime D: type) [:0]const u8 {
    return "arp_qtp_" ++ comptime baseName(D);
}

/// Memory access for `evalRange`/`limitRange`. `device` changes only how
/// pointers are reached: the host indexes plain slices (`GlobalPtr(T)` is
/// `[*]T`), the GPU casts `.global` kernel arguments to the generic address
/// space the contract's `eval` takes. Host-only state is `void` under
/// `device`. `skip_const` drops stamps of a constant Jacobian half.
/// `staged` (host only) stores each stamp at its own tape position instead
/// of adding it into its plane cell: `rhs`/`q_vec` are indexed `id * n_u +
/// ru` and `g_vals`/`c_vals` like `slots`, both relative to the batch, and a
/// ground stamp lands on its own position too. ParEval then sums the
/// positions into the planes in tape order (`Hooks.stage`).
fn Sink(comptime D: type, comptime device: bool, comptime skip_const: bool, comptime staged: bool) type {
    if (device and staged) @compileError("staging is host only");
    const n_u: usize = comptime contract.nU(D);
    const const_g = @hasDecl(D, "constant") and D.constant.g;
    const const_c = @hasDecl(D, "constant") and D.constant.c;
    const BatchT = DeviceBatch(D);
    return struct {
        xs: gompute.GlobalPtr(f64),
        gath_: gompute.GlobalPtr(u32),
        rhs_idx_: gompute.GlobalPtr(u32),
        slots_: gompute.GlobalPtr(u32),
        models_: gompute.GlobalPtr(D.Model),
        model_of_: gompute.GlobalPtr(u32),
        instances_: gompute.GlobalPtr(D.Instance),
        g_vals: gompute.GlobalPtr(f64),
        c_vals: gompute.GlobalPtr(f64),
        rhs: gompute.GlobalPtr(f64),
        q_vec: gompute.GlobalPtr(f64),
        /// The lim plane (`count * LimMap(D).k`). Undefined, and never read,
        /// when D has no `limit`.
        lim_: gompute.GlobalPtr(f64),
        /// `x_old`; read only by `limitRange`.
        xo: gompute.GlobalPtr(f64),
        /// The batch's `q_tape`, host only. Held as a bare pointer: through
        /// the batch, every plane store might alias the slice header, and
        /// LLVM reloaded it before each charge store.
        q_tape: if (device or !@hasDecl(D, "q")) void else [*]f64,

        // `Circuit.computeBaseline` stamps only batches whose whole Jacobian
        // is constant (`Batch.has_const_jacobian`). A lone constant half has
        // no baseline copy, so skipping it would drop it from the Newton
        // matrix: an idt's charge (C = 1) beside a non-constant G, say.
        const in_baseline = const_g and (!@hasDecl(D, "q") or const_c);
        pub const skip_g = skip_const and in_baseline;
        pub const skip_c = skip_const and in_baseline;
        pub const on_device = device;

        const Sk = @This();

        pub inline fn x(s: *const Sk, gi: u32) f64 {
            return s.xs[gi];
        }
        pub inline fn xOld(s: *const Sk, gi: u32) f64 {
            return s.xo[gi];
        }
        pub inline fn gath(s: *const Sk, id: u32, u: usize) u32 {
            return s.gath_[@as(usize, id) * n_u + u];
        }
        pub inline fn rhsRow(s: *const Sk, id: u32, ru: usize) u32 {
            if (comptime staged) return @intCast(@as(usize, id) * n_u + ru);
            return s.rhs_idx_[@as(usize, id) * n_u + ru];
        }
        pub inline fn lim(s: *const Sk, id: u32, comptime u: usize) f64 {
            return s.lim_[@as(usize, id) * LimMap(D).k + comptime LimMap(D).at(u)];
        }
        pub inline fn setLim(s: *const Sk, id: u32, comptime u: usize, v: f64) void {
            s.lim_[@as(usize, id) * LimMap(D).k + comptime LimMap(D).at(u)] = v;
        }
        // An address-space cast, not a copy: a compact model's Model has
        // hundreds of fields and would not fit in GPU registers. A no-op on
        // the host.
        pub inline fn model(s: *const Sk, id: u32) *const D.Model {
            return @addrSpaceCast(&s.models_[s.model_of_[id]]);
        }
        pub inline fn inst(s: *const Sk, id: u32) if (@hasDecl(D, "mutable_eval") and D.mutable_eval) *D.Instance else *const D.Instance {
            return @addrSpaceCast(&s.instances_[id]);
        }
        inline fn slot(s: *const Sk, id: u32, comptime ru: usize, comptime cu: usize) u32 {
            if (comptime staged) return @intCast(@as(usize, id) * SlotMap(D).k + comptime SlotMap(D).at(ru, cu));
            return s.slots_[@as(usize, id) * SlotMap(D).k + comptime SlotMap(D).at(ru, cu)];
        }
        // Plain `+=` on the GPU too. There the tape indexes a staging cell
        // only this thread writes, and `ReduceKernel` sums each plane cell's
        // cells in tape order; an atomic add would make the order, and so
        // the rounding, vary between runs. The staging is zeroed per pass,
        // so `0 + v` keeps signed zeros and NaNs as the host stamp does.
        inline fn add(p: gompute.GlobalPtr(f64), i: u32, v: f64) void {
            // A staged position takes one stamp per pass.
            if (comptime staged) p[i] = v else p[i] += v;
        }
        pub inline fn scatterRes(s: *const Sk, row: u32, val: f64) void {
            add(s.rhs, row, val);
        }
        pub inline fn scatterJac(s: *const Sk, id: u32, comptime ru: usize, comptime cu: usize, val: f64) void {
            add(s.g_vals, s.slot(id, ru, cu), val);
        }
        pub inline fn scatterQ(s: *const Sk, row: u32, qv: f64) void {
            add(s.q_vec, row, qv);
        }
        /// Records LTE site `j` of instance `id` in the host `q_tape`.
        pub inline fn tapeQ(s: *const Sk, id: u32, j: usize, qv: f64) void {
            s.q_tape[@as(usize, id) * (comptime lteSites(D).len) + j] = qv;
        }
        pub inline fn scatterQJac(s: *const Sk, id: u32, comptime ru: usize, comptime cu: usize, val: f64) void {
            add(s.c_vals, s.slot(id, ru, cu), val);
        }

        /// Host sink over batch `b`, writing into `pl`. `xo` may be undefined
        /// outside `limitRange`.
        pub fn host(b: *BatchT, pl: *const Planes, xs: []const f64, xo: [*]const f64) Sk {
            return .{
                .xs = @constCast(xs.ptr), // GlobalPtr has no const form; never written
                .gath_ = b.gath.ptr,
                .rhs_idx_ = b.rhs_idx.ptr,
                .slots_ = b.slots.ptr,
                .models_ = b.models.ptr,
                .model_of_ = b.model_of.ptr,
                .instances_ = b.instances.ptr,
                .g_vals = pl.g_vals.ptr,
                .c_vals = pl.c_vals.ptr,
                .rhs = pl.rhs.ptr,
                .q_vec = pl.q_vec.ptr,
                .lim_ = if (comptime @hasDecl(D, "limit")) b.lim_x.ptr else undefined,
                .xo = @constCast(xo),
                .q_tape = if (comptime @hasDecl(D, "q")) b.q_tape.ptr else {},
            };
        }
    };
}

/// GPU eval kernel for D, one thread per instance, running the same
/// `evalRange` as the host through a device `Sink`.
fn DeviceKernel(comptime D: type, comptime block_size: u32) type {
    return struct {
        pub fn run(
            count: u64,
            sim: SimState,
            xs: gompute.GlobalPtr(f64),
            gath: gompute.GlobalPtr(u32),
            rhs_idx: gompute.GlobalPtr(u32),
            slots: gompute.GlobalPtr(u32),
            models: gompute.GlobalPtr(D.Model),
            model_of: gompute.GlobalPtr(u32),
            instances: gompute.GlobalPtr(D.Instance),
            g_vals: gompute.GlobalPtr(f64),
            c_vals: gompute.GlobalPtr(f64),
            rhs: gompute.GlobalPtr(f64),
            q_vec: gompute.GlobalPtr(f64),
            lim: gompute.GlobalPtr(f64),
            limiting: u64,
        ) callconv(gompute.kernel_callconv) void {
            const tid = gompute.globalIdX(block_size);
            if (tid >= count) return;
            var sink = Sink(D, true, false, false){
                .xs = xs,
                .gath_ = gath,
                .rhs_idx_ = rhs_idx,
                .slots_ = slots,
                .models_ = models,
                .model_of_ = model_of,
                .instances_ = instances,
                .g_vals = g_vals,
                .c_vals = c_vals,
                .rhs = rhs,
                .q_vec = q_vec,
                .lim_ = lim,
                .xo = undefined, // read only by limitRange
                .q_tape = {},
            };
            const id: u32 = @intCast(tid);
            // Always the wide basis here: the kernel arguments carry no
            // `narrow_count`, and they are part of the frozen GPU boundary.
            // ponytail: pass `narrow_count` once narrowing is measured on a GPU.
            evalRange(D, false, gpuJacFloat(D), false, &sink, id, id + 1, sim, limiting != 0);
        }
    };
}

/// GPU limit and state-latch kernel, one thread per instance: the device side
/// of `applyLimits` and of `updateState`. `halves` (`ir.lim_pass_*` bits)
/// picks which run; the launcher runs the limit half per Newton iterate and
/// the state half once per converged solve, as the host does (#15).
///
/// Sets bit 0 of `flags[0]` when a clamp reports not converged, and bit 1
/// when an `updateState` returns anything but `.ok`, which the launcher
/// treats as a fault and answers by falling back to the CPU.
fn StateKernel(comptime D: type, comptime block_size: u32) type {
    const n_u: usize = comptime contract.nU(D);
    const has_limit = @hasDecl(D, "limit");
    const has_state = @hasDecl(D, "State");
    const StateT = if (has_state) D.State else u8;
    return struct {
        pub fn run(
            count: u64,
            xs: gompute.GlobalPtr(f64),
            x_old: gompute.GlobalPtr(f64),
            gath: gompute.GlobalPtr(u32),
            models: gompute.GlobalPtr(D.Model),
            model_of: gompute.GlobalPtr(u32),
            instances: gompute.GlobalPtr(D.Instance),
            lim: gompute.GlobalPtr(f64),
            states: gompute.GlobalPtr(StateT),
            lim_active: u64,
            halves: u64,
            flags: gompute.GlobalPtr(u32),
            sim: SimState,
        ) callconv(gompute.kernel_callconv) void {
            const tid = gompute.globalIdX(block_size);
            if (tid >= count) return;
            const id: usize = @intCast(tid);
            const model: *const D.Model = @addrSpaceCast(&models[model_of[id]]);
            var flag: u32 = 0;
            var cur: [n_u]f64 = undefined;
            inline for (0..n_u) |u| cur[u] = xs[gath[id * n_u + u]];
            if (comptime has_limit) if (halves & ir.lim_pass_limit != 0) {
                // Must use the same write set as `limitRange`: host and
                // device share one `lim_x` plane.
                const writes = comptime limitWritesOf(D);
                const inst_c: *const D.Instance = @addrSpaceCast(&instances[id]);
                var old: [n_u]f64 = undefined;
                inline for (0..n_u) |u| if (comptime has(writes, u)) {
                    old[u] = if (lim_active != 0) lim[id * LimMap(D).k + comptime LimMap(D).at(u)] else x_old[gath[id * n_u + u]];
                } else {
                    old[u] = x_old[gath[id * n_u + u]];
                };
                var lm = D.limit(Real, model, inst_c, cur, old, sim);
                snapLimited(n_u, comptime limitReadsOf(D), writes, &lm.x, cur);
                if (!lm.converged) flag |= 1;
                inline for (0..n_u) |u| if (comptime has(writes, u)) {
                    lim[id * LimMap(D).k + comptime LimMap(D).at(u)] = lm.x[u];
                };
            };
            if (comptime has_state) if (halves & ir.lim_pass_state != 0) {
                const inst_m: *D.Instance = @addrSpaceCast(&instances[id]);
                const st: *StateT = @addrSpaceCast(&states[id]);
                switch (D.updateState(Real, model, inst_m, cur, st, sim)) {
                    .ok => {},
                    .request_reject_at => flag |= 2,
                }
            };
            if (flag != 0) _ = @atomicRmw(u32, &flags[0], .Or, flag, .monotonic);
        }
    };
}

/// Segmented sum, one output cell per thread: `out[i] = sum(in[seg[2i] ..
/// seg[2i + 1]])`. The launcher lays each cell's staging contributions out
/// contiguously in tape order, so this sums them in the order the host stamp
/// does, on every launch. Explicit ends let ranges skip the staging cells
/// that no plane cell reads (ground and structural-zero contributions). The
/// output is overwritten, not accumulated.
///
/// Strict left-to-right with one accumulator on purpose: no `.optimized`
/// float mode, and no interleaved partial sums. The tape emits rows in `ru`
/// order, so interleaving would group all the +1.8 contributions of a supply
/// row in one lane and all the -1.8 in another, measured at 4e-12 error
/// against 1.6e-17 in order. The launcher bounds the chain length instead.
/// The loads go out eight at a time ahead of the in-order adds, so a thread
/// waits on memory once per eight contributions, not once per contribution.
fn ReduceKernel(comptime _: type, comptime block_size: u32) type {
    return struct {
        pub fn run(
            n_cells: u64,
            seg: gompute.GlobalPtr(u32),
            stage: gompute.GlobalPtr(f64),
            plane: gompute.GlobalPtr(f64),
        ) callconv(gompute.kernel_callconv) void {
            const tid = gompute.globalIdX(block_size);
            if (tid >= n_cells) return;
            const i: usize = @intCast(tid);
            plane[i] = segmentSum(stage, seg[2 * i], seg[2 * i + 1]);
        }
    };
}

/// `stage[first..end]` summed strictly left to right, the loads issued eight at
/// a time. Split out of `ReduceKernel` so the host tests it against the plain
/// loop: tests/eval.zig.
inline fn segmentSum(stage: gompute.GlobalPtr(f64), first: u32, end: u32) f64 {
    var sum: f64 = 0;
    var k = first;
    while (k + 8 <= end) : (k += 8) {
        var v: [8]f64 = undefined;
        inline for (&v, 0..) |*e, j| e.* = stage[k + j];
        inline for (v) |e| sum += e;
    }
    while (k < end) : (k += 1) sum += stage[k];
    return sum;
}

/// GPU charge-tape kernel, one thread per instance: the LTE charges
/// `evalQRange` records on the host, at `xs`, into `tape` (`count *
/// lteSites(D).len`). Same `RealFor` basis, so the charges match the host
/// tape to the device's rounding. The launcher runs it lazily, once per
/// transient step, instead of widening the frozen eval kernel's arguments.
fn QTapeKernel(comptime D: type, comptime block_size: u32) type {
    const n_u: usize = comptime contract.nU(D);
    const sites = comptime lteSites(D);
    return struct {
        pub fn run(
            count: u64,
            sim: SimState,
            xs: gompute.GlobalPtr(f64),
            gath: gompute.GlobalPtr(u32),
            models: gompute.GlobalPtr(D.Model),
            model_of: gompute.GlobalPtr(u32),
            instances: gompute.GlobalPtr(D.Instance),
            tape: gompute.GlobalPtr(f64),
        ) callconv(gompute.kernel_callconv) void {
            const tid = gompute.globalIdX(block_size);
            if (tid >= count) return;
            const id: usize = @intCast(tid);
            const S = RealFor(@hasDecl(D, "collapse"));
            var lx: [n_u]f64 = undefined;
            inline for (0..n_u) |u| lx[u] = xs[gath[id * n_u + u]];
            const qs = D.q(S, &lx, @addrSpaceCast(&models[model_of[id]]), @addrSpaceCast(&instances[id]), sim);
            const mf = mfactorOf(D, &instances[id]);
            inline for (sites, 0..) |k, j| tape[id * sites.len + j] = qs[k].v * mf;
        }
    };
}

/// GPU accepted-step kernel, one thread per instance: runs `D.stateCtl` with
/// `op` on the resident Instance/State blobs and ORs its result into bit 0
/// of `flags[0]`.
fn CtlKernel(comptime D: type, comptime block_size: u32) type {
    const StateT = if (@hasDecl(D, "State")) D.State else u8;
    return struct {
        pub fn run(
            count: u64,
            models: gompute.GlobalPtr(D.Model),
            model_of: gompute.GlobalPtr(u32),
            instances: gompute.GlobalPtr(D.Instance),
            states: gompute.GlobalPtr(StateT),
            op: u64,
            flags: gompute.GlobalPtr(u32),
        ) callconv(gompute.kernel_callconv) void {
            const tid = gompute.globalIdX(block_size);
            if (tid >= count) return;
            const id: usize = @intCast(tid);
            const model: *const D.Model = @addrSpaceCast(&models[model_of[id]]);
            const inst: *D.Instance = @addrSpaceCast(&instances[id]);
            const st: *StateT = @addrSpaceCast(&states[id]);
            const sop: StateCtlOp = @fromBackingInt(@intCast(@as(u8, @truncate(op))));
            if (D.stateCtl(model, inst, st, sop))
                _ = @atomicRmw(u32, &flags[0], .Or, 1, .monotonic);
        }
    };
}

/// Memory access for `evalRange` over lane `l` of `n` lanes, lane-major:
/// unknown gi at `xs[gi * n + l]`, plane cell c at `plane[c * n + l]`,
/// instance id's row at `instances[id * n + l]` and its Model at
/// `models[model_of[id * n + l]]`; the gather, scatter and slot tapes are
/// the batch's own, shared by every lane. One thread walks every instance
/// of its lane, so it alone writes its lane's cells: adds land in tape
/// order with no staging and no atomics (dev/research/plans/phase4).
fn LaneSink(comptime D: type) type {
    const n_u: usize = comptime contract.nU(D);
    return struct {
        n: u32,
        l: u32,
        xs: gompute.GlobalPtr(f64),
        gath_: gompute.GlobalPtr(u32),
        rhs_idx_: gompute.GlobalPtr(u32),
        slots_: gompute.GlobalPtr(u32),
        models_: gompute.GlobalPtr(D.Model),
        model_of_: gompute.GlobalPtr(u32),
        instances_: gompute.GlobalPtr(D.Instance),
        g_vals: gompute.GlobalPtr(f64),
        c_vals: gompute.GlobalPtr(f64),
        rhs: gompute.GlobalPtr(f64),
        q_vec: gompute.GlobalPtr(f64),
        /// Lane-major lim plane: instance id's limited unknown `at(u)` at
        /// `(id * k + at(u)) * n + l`.
        lim_: gompute.GlobalPtr(f64),
        /// Lane l's tape slot (`LaneChargeKernel`), else undefined.
        tape_: gompute.GlobalPtr(f64) = undefined,

        pub const skip_g = false;
        pub const skip_c = false;
        pub const on_device = true;
        const Sk = @This();

        inline fn at(s: *const Sk, i: usize) usize {
            return i * s.n + s.l;
        }
        pub inline fn x(s: *const Sk, gi: u32) f64 {
            return s.xs[s.at(gi)];
        }
        pub inline fn gath(s: *const Sk, id: u32, u: usize) u32 {
            return s.gath_[@as(usize, id) * n_u + u];
        }
        pub inline fn rhsRow(s: *const Sk, id: u32, ru: usize) u32 {
            return s.rhs_idx_[@as(usize, id) * n_u + ru];
        }
        pub inline fn lim(s: *const Sk, id: u32, comptime u: usize) f64 {
            return s.lim_[s.at(@as(usize, id) * LimMap(D).k + comptime LimMap(D).at(u))];
        }
        pub inline fn model(s: *const Sk, id: u32) *const D.Model {
            return @addrSpaceCast(&s.models_[s.model_of_[s.at(id)]]);
        }
        pub inline fn inst(s: *const Sk, id: u32) if (@hasDecl(D, "mutable_eval") and D.mutable_eval) *D.Instance else *const D.Instance {
            return @addrSpaceCast(&s.instances_[s.at(id)]);
        }
        inline fn slot(s: *const Sk, id: u32, comptime ru: usize, comptime cu: usize) u32 {
            return s.slots_[@as(usize, id) * SlotMap(D).k + comptime SlotMap(D).at(ru, cu)];
        }
        pub inline fn scatterRes(s: *const Sk, row: u32, val: f64) void {
            s.rhs[s.at(row)] += val;
        }
        pub inline fn scatterJac(s: *const Sk, id: u32, comptime ru: usize, comptime cu: usize, val: f64) void {
            s.g_vals[s.at(s.slot(id, ru, cu))] += val;
        }
        pub inline fn scatterQ(s: *const Sk, row: u32, qv: f64) void {
            s.q_vec[s.at(row)] += qv;
        }
        pub inline fn scatterQJac(s: *const Sk, id: u32, comptime ru: usize, comptime cu: usize, val: f64) void {
            s.c_vals[s.at(s.slot(id, ru, cu))] += val;
        }
        /// LTE site `j` of instance `id` into lane l's tape slot.
        pub inline fn tapeQ(s: *const Sk, id: u32, j: usize, qv: f64) void {
            s.tape_[@as(usize, id) * (comptime lteSites(D).len) + j] = qv;
        }
    };
}

/// GPU lane eval for D: thread l is lane l of `n_lanes`, evaluating every
/// instance of the batch at its own x under its own `sims[l]`, skipped
/// when `active[l] == 0` (a frozen or finished lane). `limiting[0]` is the
/// batch's lim-active word. Planes must be zeroed first; each plane cell
/// then sums its contributions in the host stamp's order.
fn LaneEvalKernel(comptime D: type, comptime block_size: u32) type {
    return struct {
        pub fn run(
            n_lanes: u64,
            count: u64,
            sims: gompute.GlobalPtr(SimState),
            active: gompute.GlobalPtr(u8),
            limiting: gompute.GlobalPtr(u32),
            xs: gompute.GlobalPtr(f64),
            gath: gompute.GlobalPtr(u32),
            rhs_idx: gompute.GlobalPtr(u32),
            slots: gompute.GlobalPtr(u32),
            models: gompute.GlobalPtr(D.Model),
            model_of: gompute.GlobalPtr(u32),
            instances: gompute.GlobalPtr(D.Instance),
            g_vals: gompute.GlobalPtr(f64),
            c_vals: gompute.GlobalPtr(f64),
            rhs: gompute.GlobalPtr(f64),
            q_vec: gompute.GlobalPtr(f64),
            lim: gompute.GlobalPtr(f64),
        ) callconv(gompute.kernel_callconv) void {
            const tid = gompute.globalIdX(block_size);
            if (tid >= n_lanes) return;
            const l: u32 = @intCast(tid);
            if (active[l] == 0) return;
            var sink: LaneSink(D) = .{
                .n = @intCast(n_lanes),
                .l = l,
                .xs = xs,
                .gath_ = gath,
                .rhs_idx_ = rhs_idx,
                .slots_ = slots,
                .models_ = models,
                .model_of_ = model_of,
                .instances_ = instances,
                .g_vals = g_vals,
                .c_vals = c_vals,
                .rhs = rhs,
                .q_vec = q_vec,
                .lim_ = lim,
            };
            evalRange(D, false, gpuJacFloat(D), false, &sink, 0, @intCast(count), sims[l], limiting[0] != 0);
        }
    };
}

/// GPU lane limit/state kernel: `StateKernel` per (instance, lane), lanes
/// innermost (thread t is lane t % n_lanes of instance t / n_lanes), for
/// the lanes with `mask[l] != 0`. ORs bit 0 (not converged), bit 1 (a
/// reject request) and bit 2 (a finite `$bound_step`) into `flags[l]`; the
/// lane path hands a lane with bit 1 or 2 back to the host.
fn LaneStateKernel(comptime D: type, comptime block_size: u32) type {
    const n_u: usize = comptime contract.nU(D);
    const has_limit = @hasDecl(D, "limit");
    const has_state = @hasDecl(D, "State");
    const StateT = if (has_state) D.State else u8;
    return struct {
        pub fn run(
            n_lanes: u64,
            count: u64,
            mask: gompute.GlobalPtr(u8),
            xs: gompute.GlobalPtr(f64),
            x_old: gompute.GlobalPtr(f64),
            gath: gompute.GlobalPtr(u32),
            models: gompute.GlobalPtr(D.Model),
            model_of: gompute.GlobalPtr(u32),
            instances: gompute.GlobalPtr(D.Instance),
            lim: gompute.GlobalPtr(f64),
            states: gompute.GlobalPtr(StateT),
            lim_active: gompute.GlobalPtr(u32),
            halves: u64,
            flags: gompute.GlobalPtr(u32),
            sims: gompute.GlobalPtr(SimState),
        ) callconv(gompute.kernel_callconv) void {
            const tid = gompute.globalIdX(block_size);
            if (tid >= n_lanes * count) return;
            const n: usize = @intCast(n_lanes);
            const l: usize = @intCast(tid % n_lanes);
            const id: usize = @intCast(tid / n_lanes);
            if (mask[l] == 0) return;
            const sim = sims[l];
            const model: *const D.Model = @addrSpaceCast(&models[model_of[id * n + l]]);
            var flag: u32 = 0;
            var cur: [n_u]f64 = undefined;
            inline for (0..n_u) |u| cur[u] = xs[@as(usize, gath[id * n_u + u]) * n + l];
            if (comptime has_limit) if (halves & ir.lim_pass_limit != 0) {
                const writes = comptime limitWritesOf(D);
                const k = comptime LimMap(D).k;
                const inst_c: *const D.Instance = @addrSpaceCast(&instances[id * n + l]);
                var old: [n_u]f64 = undefined;
                inline for (0..n_u) |u| {
                    const xo = x_old[@as(usize, gath[id * n_u + u]) * n + l];
                    old[u] = if (comptime has(writes, u))
                        (if (lim_active[0] != 0) lim[(id * k + comptime LimMap(D).at(u)) * n + l] else xo)
                    else
                        xo;
                }
                var lm = D.limit(Real, model, inst_c, cur, old, sim);
                snapLimited(n_u, comptime limitReadsOf(D), writes, &lm.x, cur);
                if (!lm.converged) flag |= 1;
                inline for (0..n_u) |u| if (comptime has(writes, u)) {
                    lim[(id * k + comptime LimMap(D).at(u)) * n + l] = lm.x[u];
                };
            };
            if (comptime has_state) if (halves & ir.lim_pass_state != 0) {
                const inst_m: *D.Instance = @addrSpaceCast(&instances[id * n + l]);
                const st: *StateT = @addrSpaceCast(&states[id * n + l]);
                switch (D.updateState(Real, model, inst_m, cur, st, sim)) {
                    .ok => {},
                    .request_reject_at => flag |= 2,
                }
                // A finite §9.17.2 `$bound_step`: the host's step control
                // must read it, so the lane leaves the device (bit 2).
                if (comptime @hasField(D.Instance, "bound_step")) if (inst_m.bound_step < std.math.inf(f64)) {
                    flag |= 4;
                };
            };
            if (flag != 0) _ = @atomicRmw(u32, &flags[l], .Or, flag, .monotonic);
        }
    };
}

/// GPU lane accepted-step kernel: `CtlKernel` per (instance, lane), lanes
/// innermost, running `D.stateCtl` with lane l's own op (`ops[l]`, a
/// `StateCtlOp` + 1; 0 skips the lane). ORs a query hit into `flags[l]`.
fn LaneCtlKernel(comptime D: type, comptime block_size: u32) type {
    const StateT = if (@hasDecl(D, "State")) D.State else u8;
    return struct {
        pub fn run(
            n_lanes: u64,
            count: u64,
            ops: gompute.GlobalPtr(u8),
            models: gompute.GlobalPtr(D.Model),
            model_of: gompute.GlobalPtr(u32),
            instances: gompute.GlobalPtr(D.Instance),
            states: gompute.GlobalPtr(StateT),
            flags: gompute.GlobalPtr(u32),
        ) callconv(gompute.kernel_callconv) void {
            const tid = gompute.globalIdX(block_size);
            if (tid >= n_lanes * count) return;
            const n: usize = @intCast(n_lanes);
            const l: usize = @intCast(tid % n_lanes);
            const id: usize = @intCast(tid / n_lanes);
            const op = ops[l];
            if (op == 0) return;
            const model: *const D.Model = @addrSpaceCast(&models[model_of[id * n + l]]);
            const inst: *D.Instance = @addrSpaceCast(&instances[id * n + l]);
            const st: *StateT = @addrSpaceCast(&states[id * n + l]);
            const sop: StateCtlOp = @fromBackingInt(@intCast(op - 1));
            if (D.stateCtl(model, inst, st, sop))
                _ = @atomicRmw(u32, &flags[l], .Or, 1, .monotonic);
        }
    };
}

/// GPU lane charge kernel: the device side of `Circuit.evalQ` for lane l of
/// `n_lanes` (thread l walks every instance, as `LaneEvalKernel`):
/// `evalQRange` adds each instance's charges into lane l's q plane (zeroed
/// first) and writes its LTE sites into slot `slot0[l]` of lane l's
/// lane-minor tape ring, site j of instance id at `((l * n_hist +
/// slot0[l]) * n_qt) + off + id * sites + j`. Skips `mask[l] == 0`.
fn LaneChargeKernel(comptime D: type, comptime block_size: u32) type {
    return struct {
        pub fn run(
            n_lanes: u64,
            count: u64,
            mask: gompute.GlobalPtr(u8),
            sims: gompute.GlobalPtr(SimState),
            xs: gompute.GlobalPtr(f64),
            gath: gompute.GlobalPtr(u32),
            rhs_idx: gompute.GlobalPtr(u32),
            models: gompute.GlobalPtr(D.Model),
            model_of: gompute.GlobalPtr(u32),
            instances: gompute.GlobalPtr(D.Instance),
            q_vec: gompute.GlobalPtr(f64),
            tape: gompute.GlobalPtr(f64),
            slot0: gompute.GlobalPtr(u8),
            n_hist: u64,
            n_qt: u64,
            off: u64,
        ) callconv(gompute.kernel_callconv) void {
            const tid = gompute.globalIdX(block_size);
            if (tid >= n_lanes) return;
            const l: u32 = @intCast(tid);
            if (mask[l] == 0) return;
            var sink: LaneSink(D) = .{
                .n = @intCast(n_lanes),
                .l = l,
                .xs = xs,
                .gath_ = gath,
                .rhs_idx_ = rhs_idx,
                .slots_ = undefined,
                .models_ = models,
                .model_of_ = model_of,
                .instances_ = instances,
                .g_vals = undefined,
                .c_vals = undefined,
                .rhs = undefined,
                .q_vec = q_vec,
                .lim_ = undefined,
                .tape_ = tape + ((@as(usize, l) * @as(usize, @intCast(n_hist)) + slot0[l]) * @as(usize, @intCast(n_qt)) + @as(usize, @intCast(off))),
            };
            evalQRange(D, RealFor(@hasDecl(D, "collapse")), &sink, 0, @intCast(count), sims[l], null);
        }
    };
}

/// What this simulator offers D, checked by `contract.validateHost`: Newton
/// iteration hooks, mutable evaluation, and the VPI application behind D's
/// `$systf` calls (LRM §12.32).
fn VpiHost(comptime D: type) type {
    return struct {
        pub const iteration_hooks = true;
        /// The batch runs `setup` once before `initState` (after `.options tnom`
        /// is on the card), and `reprep` reruns it after every parameter or
        /// temperature write.
        pub const calls_setup = true;
        pub const mutable_eval = true;
        /// Every small-signal matrix adds the device's `acDyn` terms
        /// (`Hooks.ac_dyn`).
        pub const calls_ac_dyn = true;
        /// Null: ESPice binds the application per instance instead, through
        /// `DeviceVtable.bind_systf`, because it is chosen at run time (a
        /// `--vpi` application, or a no-op for task calls only) and refused
        /// by name before staging when there is none (`DeviceVtable.systf_calls`).
        pub fn systf(_: *const D.Model) ?*const contract.SystfHost {
            return null;
        }
    };
}

/// Compile error unless this host provides everything D requires. The check
/// lives here rather than in `contract.validate` because a device compiled to
/// a `.so` cannot know which simulator will load it.
pub fn checkHost(comptime D: type) void {
    contract.validateHost(VpiHost(D), D);
}

/// Exports D under the runtime device ABI (`arp_abi_version`,
/// `arp_layout_hash`, `arp_device`). The generated `.so` shim calls this:
/// `comptime { @import("dyn").exportDevice(@import("device"), "name"); }`.
pub fn exportDevice(comptime D: type, comptime device_name: []const u8) void {
    comptime checkHost(D);
    const impl = Impl(D, device_name);
    @export(&impl.abiVersion, .{ .name = "arp_abi_version" });
    @export(&impl.layoutHashC, .{ .name = "arp_layout_hash" });
    @export(&impl.getVtable, .{ .name = "arp_device" });
}

/// D's vtable without going through a shared library.
pub fn deviceVtable(comptime D: type, comptime device_name: []const u8) *const DeviceVtable {
    return &Impl(D, device_name).vtable;
}

fn Impl(comptime D: type, comptime device_name: []const u8) type {
    return struct {
        const Store = ProtoStore(D);
        const n_u: usize = contract.nU(D);

        fn abiVersion() callconv(.c) u32 {
            return ir.abi_version;
        }
        fn layoutHashC() callconv(.c) u64 {
            return ir.layoutHash();
        }
        fn getVtable() callconv(.c) *const DeviceVtable {
            return &vtable;
        }

        const vtable: DeviceVtable = .{
            .name = device_name,
            .n_u = n_u,
            .num_ports = D.num_ports,
            .model_size = @sizeOf(D.Model),
            .instance_size = @sizeOf(D.Instance),
            .init_model = initBlob(D.Model),
            .init_instance = initBlob(D.Instance),
            .bind_model = bindFn(D.Model),
            .bind_instance = bindFn(D.Instance),
            .derive = if (@hasDecl(D, "derive")) deriveFn else null,
            .collapse = if (@hasDecl(D, "collapse")) collapseFn else null,
            .proto_create = protoCreate,
            .proto_add = protoAdd,
            .unknown_names = &unknown_names,
            .systf_calls = if (has_systf) &D.systf_calls else &.{},
            .bind_systf = if (has_systf) bindSystf else null,
        };

        const has_systf = @hasDecl(D, "systf_calls") and D.systf_calls.len != 0;

        fn bindSystf(instance: [*]u8, host: *const contract.SystfHost) void {
            const i: *D.Instance = @ptrCast(@alignCast(instance));
            i.systf = host;
        }

        const unknown_names: [n_u][]const u8 = blk: {
            var out: [n_u][]const u8 = undefined;
            for (&out, @typeInfo(D.U).@"enum".field_names) |*o, f| o.* = f;
            break :blk out;
        };

        fn initBlob(comptime T: type) *const fn ([*]u8) void {
            return struct {
                fn f(dest: [*]u8) void {
                    const p: *T = @ptrCast(@alignCast(dest));
                    p.* = .{};
                }
            }.f;
        }

        fn bindFn(comptime T: type) *const fn ([*]u8, []const ir.Param) ir.BindStatus {
            return struct {
                fn f(dest: [*]u8, params: []const ir.Param) ir.BindStatus {
                    return ir.bind.apply(@as(*T, @ptrCast(@alignCast(dest))), params);
                }
            }.f;
        }

        fn deriveFn(model: [*]u8) void {
            const m: *D.Model = @ptrCast(@alignCast(model));
            D.derive(Real, m);
        }

        fn collapseFn(model: [*]const u8, instance: [*]const u8, out: [*]i32) void {
            const m: *const D.Model = @ptrCast(@alignCast(model));
            const i: *const D.Instance = @ptrCast(@alignCast(instance));
            const col = D.collapse(Real, m, i);
            inline for (D.num_ports..n_u) |u|
                out[u] = if (col[u]) |p| @intCast(p) else -1;
        }

        fn protoCreate(gpa: std.mem.Allocator) ir.DeviceResult(Proto) {
            const store = gpa.create(Store) catch return .out_of_memory;
            store.* = .{};
            return .{ .ok = .{
                .ctx = store,
                .type_name = device_name,
                .pattern = Store.addPattern,
                .finalize = Store.finalize,
                .destroy = Store.destroy,
                .apply_perm = Store.applyPerm,
            } };
        }

        // The rows live on `staging_gpa`, not the ABI's allocator.
        fn protoAdd(ctx: *anyopaque, _: std.mem.Allocator, model: [*]const u8, instance: [*]const u8, nodes: [*]const u32) ir.DeviceResult(void) {
            const store: *Store = @ptrCast(@alignCast(ctx));
            const m: *const D.Model = @ptrCast(@alignCast(model));
            const i: *const D.Instance = @ptrCast(@alignCast(instance));
            return ir.DeviceResult(void).fromLocal(store.append(m, i, nodes[0..n_u].*));
        }
    };
}

fn placeholder(_: u64) callconv(gompute.kernel_callconv) void {}

// As the build root, export every model in `models`: its GPU kernels (or a
// no-op placeholder when it is not GPU-eligible) in a device compilation, and
// its `arp_device_<name>` vtable getter on the host.
comptime {
    if (@import("root") == @This() and !builtin.is_test) {
        for (@typeInfo(@import("models")).@"struct".decl_names) |decl_name| {
            // `gpu_kernels` is a build flag, not a device.
            if (@TypeOf(@field(@import("models"), decl_name)) != type) continue;
            const D = @field(@import("models"), decl_name);
            if (gompute.is_device) {
                const block_size = ir.gpu_block_size;
                if (gpuEligible(D)) {
                    gompute.exportRaw(kernelName(D), &DeviceKernel(D, block_size).run);
                    if (hasStateKernel(D)) gompute.exportRaw(stateKernelName(D), &StateKernel(D, block_size).run);
                    if (hasCtlKernel(D)) gompute.exportRaw(ctlKernelName(D), &CtlKernel(D, block_size).run);
                    if (@hasDecl(D, "q")) gompute.exportRaw(qTapeKernelName(D), &QTapeKernel(D, block_size).run);
                    gompute.exportRaw(reduceKernelName(D), &ReduceKernel(D, block_size).run);
                    // `-Dgpu-lanes`: also the lane kernels (phase 4), always
                    // at the lane block width (`lane_block_size`).
                    if (@import("lane_options").enabled) {
                        const lb = lane_block_size;
                        gompute.exportRaw(laneKernelName(D, "eval"), &LaneEvalKernel(D, lb).run);
                        if (hasStateKernel(D)) gompute.exportRaw(laneKernelName(D, "lim"), &LaneStateKernel(D, lb).run);
                        if (hasCtlKernel(D)) gompute.exportRaw(laneKernelName(D, "ctl"), &LaneCtlKernel(D, lb).run);
                        if (@hasDecl(D, "q")) gompute.exportRaw(laneKernelName(D, "chg"), &LaneChargeKernel(D, lb).run);
                    }
                } else gompute.exportRaw("arp_nop_" ++ decl_name, &placeholder);
            } else {
                checkHost(D);
                // A built-in has no `.hdl` card for the host to refuse by name.
                if (@hasDecl(D, "systf_calls") and D.systf_calls.len != 0)
                    @compileError("built-in model " ++ decl_name ++ " calls " ++ D.systf_calls[0].name ++
                        ": no VPI application is registered (LRM 12.32), so its value is unknown; see #197");
                if (@hasDecl(D, "eval")) {
                    const Export = struct {
                        fn get() callconv(.c) *const DeviceVtable {
                            return deviceVtable(D, @typeName(D));
                        }
                    };
                    @export(&Export.get, .{ .name = "arp_device_" ++ decl_name });
                }
            }
        }
        gompute.exportKernels(.{});
    }
}

/// Private decls exposed to the test suites. Tests live in tests/eval.zig,
/// not here: this file is a dependency module of every test root, and Zig
/// runs only the root module's tests.
pub const test_access = if (@import("builtin").is_test) .{
    .gpuRefusal = gpuRefusal,
    .GpuRefusal = GpuRefusal,
    .Real = Real,
    .Sparse = DualFor(f64, &.{ 0, 1 }, host_pad, false),
    .SparseF32 = DualFor(f32, &.{ 0, 1 }, host_pad, false),
    // Three lanes pad to four: the shuffle path with a pad lane.
    .Sparse3 = DualFor(f64, &.{ 0, 1, 2 }, host_pad, false),
    .anyNonzero = anyNonzero,
    .segmentSum = segmentSum,
    .repMask = repMask,
    .spicePulseBreak = spicePulseBreak,
    .spicePwlBreak = spicePwlBreak,
    .ParamRef = ParamRef,
    .PatternView = PatternView,
} else {};

test {
    _ = @import("ltra_ac.zig");
}
